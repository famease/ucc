// import { AdminEvents } from "@/components/admin-events";
// import { EventForm } from "@/components/event-form";
// import React from "react";

// function page() {
//   return (
//     <div className="container mx-auto">
//       <AdminEvents/>
//     </div>
//   );
// }

// export default page;
