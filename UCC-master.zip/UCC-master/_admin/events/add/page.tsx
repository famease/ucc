// import { EventForm } from "@/components/event-form";
// import React from "react";

// function page() {
//   return (
//     <div>
//       <EventForm />
//     </div>
//   );
// }

// export default page;
