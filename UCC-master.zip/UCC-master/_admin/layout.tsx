import type { Metadata } from "next";
import { AdminTopNavComponent } from "@/components/admin-side-nav";

export const metadata: Metadata = {
  title: "UCC Admin",
  description: "Admin page for UCC",
};

export default function AdminLayout({
  children,
}: Readonly<{
  children: React.ReactNode;
}>) {
  return (
    <div className=" min-h-screen bg-gray-100">
        <main className="p-6 ">
          <AdminTopNavComponent />
          {children}
        </main>
      </div>
  );
}
