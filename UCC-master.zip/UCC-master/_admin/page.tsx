"use client";
import { SignedIn, SignedOut, useUser } from "@clerk/nextjs";
import React, { useEffect } from "react";
// import { useRouter } from "next/router";

function page() {
//   const { user } = useUser();
//   const router = useRouter();

//   // // Redirect to login page if not an admin
//   // useEffect(() => {
//   //   if (user && !user.roles.includes("admin")) {
//   //     router.push("/login");
//   //   }
//   // }, [user, router]);

  return (
    <div>
      <SignedIn>
        <h1>Admin Page</h1>
      </SignedIn>
      <SignedOut>
        <h1>Please sign in to view this page</h1>
      </SignedOut>
    </div>
  );
}

export default page;
