'use client'

import { useEffect, useState } from 'react'
import Image from "next/image"

export default function AuthLayout({ children }: { children: React.ReactNode }) {
  const [mounted, setMounted] = useState(false)

  useEffect(() => {
    setMounted(true)
  }, [])

  return (
    <div className="flex min-h-screen bg-gradient-to-br from-blue-100 to-green-100">
      {/* Left side - Image, Title, and Animations */}
      <div className="relative hidden w-1/2 flex-col items-center justify-center overflow-hidden lg:flex">
        <div className="z-10 text-center">
          <Image
            src="/placeholder.svg?height=150&width=150"
            alt="UCC Logo"
            width={150}
            height={150}
            className="mx-auto h-32 w-32"
          />
          <h1 className="mt-6 text-4xl font-bold text-gray-900">
            Welcome to UCC
          </h1>
          <p className="mt-2 text-xl text-gray-600">
            United in faith, open to all
          </p>
        </div>

        {/* Background Animation */}
        {mounted && (
          <span>
            <div className="animate-float absolute -left-16 -top-16 h-64 w-64 rounded-full bg-blue-200 opacity-50" />
            <div className="animate-float animation-delay-1000 absolute -bottom-16 -right-16 h-64 w-64 rounded-full bg-green-200 opacity-50" />
            <div className="animate-float animation-delay-2000 absolute left-1/2 top-1/2 h-64 w-64 -translate-x-1/2 -translate-y-1/2 rounded-full bg-yellow-200 opacity-50" />
          </span>
        )}
      </div>

      {/* Right side - Form */}
      <div className="flex w-full items-center justify-center p-4 lg:w-1/2">
        <div className="w-full max-w-md space-y-8 rounded-2xl bg-white p-6 shadow-xl">
          <div className="text-center lg:hidden">
            <Image
              src="/placeholder.svg?height=100&width=100"
              alt="UCC Logo"
              width={100}
              height={100}
              className="mx-auto h-24 w-24"
            />
            <h2 className="mt-6 text-3xl font-bold text-gray-900">
              Welcome to UCC
            </h2>
            <p className="mt-2 text-sm text-gray-600">
              Sign in to connect with your community
            </p>
          </div>

          {/* Clerk Auth Form Placeholder */}
          <div className="mt-8">
            {children}
          </div>
        </div>
      </div>
    </div>
  )
}