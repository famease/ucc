"use client";
import { SignedIn, SignIn, UserButton } from "@clerk/clerk-react";
import { User } from "@clerk/nextjs/server";
import React from "react";

function page() {
  return (
    <div className="container">
      <SignIn />
    </div>
  );
}
export default page;
