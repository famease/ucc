type MinistryType = 'youth' | 'cr' | 'missions';

export const generateMinistrySchema = (ministry: MinistryType) => {
  const ministries = {
    youth: {
      name: 'One2Nine Generation',
      description: 'Youth programs focused on faith, leadership, and personal growth'
    },
    cr: {
      name: 'Celebrate Recovery',
      description: 'Christ-centered recovery program',
      event: {
        '@type': 'Event',
        name: 'Celebrate Recovery Meeting',
        startDate: 'YYYY-MM-DDT18:30',
        endDate: 'YYYY-MM-DDT20:00',
        dayOfWeek: 'Friday'
      }
    },
    missions: {
      name: 'UCC Missions',
      description: 'Provides meals to school children and food parcels to the community',
      contactPoint: {
        '@type': 'ContactPoint',
        name: 'Randolph Beyers',
        telephone: '078 070 0179'
      }
    }
  } as const;

  return {
    '@context': 'https://schema.org',
    '@type': 'Organization',
    ...ministries[ministry]
  }
}