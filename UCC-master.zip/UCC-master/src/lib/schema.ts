export const generateMainSchema = () => ({
  "@context": "https://schema.org",
  "@type": "Church",
  name: "Upperroom Christian Center",
  url: "https://ucc-eta.vercel.app/",
  telephone: "011 683 0075",
  email: "uccjhbsouth@gmail.com",
  address: {
    "@type": "PostalAddress",
    streetAddress: "2-4 Reeders St",
    addressLocality: "Haddon",
    addressRegion: "Johannesburg",
    postalCode: "2190",
    addressCountry: "ZA",
  },
  sameAs: [
    "https://www.facebook.com/uc.christian.9/",
    "https://www.instagram.com/one2ninegen/",
  ],
});
