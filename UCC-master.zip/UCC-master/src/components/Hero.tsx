"use client";

import Image from "next/image";
import Link from "next/link";
import { Button } from "@/components/ui/button";

export function Hero() {
  return (
    <div className="relative h-[calc(100vh-4rem)] min-h-[600px] w-full overflow-hidden">
      <Image
        src="/cross.webp"
        alt="Church community"
        layout="fill"
        objectFit="cover"
        priority
        className="absolute inset-0 z-0"
      />
      <div className="absolute inset-0 bg-black bg-opacity-50 z-10"></div>
      <div className="relative z-20 h-full flex flex-col justify-center items-center text-center text-white px-4 sm:px-6 lg:px-8">
        <h1 className="text-4xl sm:text-5xl md:text-6xl font-bold mb-4 tracking-tight">
          The Upperroom Christian Center
        </h1>
        <p className="text-xl sm:text-2xl md:text-3xl mb-8 max-w-3xl">
          A vibrant Christian community in Johannesburg South
        </p>
        <div className="flex flex-col sm:flex-row gap-4">
          <Button
            asChild
            size="lg"
            className="bg-primary hover:bg-primary/90 text-primary-foreground"
          >
            <Link href="/about">Learn More</Link>
          </Button>
          <Button
            asChild
            size="lg"
            variant="outline"
            className="bg-white/10 hover:bg-white/20 text-white border-white"
          >
            <Link href="/contact">Join Us in Worship</Link>
          </Button>
        </div>
      </div>
      <div className="absolute bottom-0 left-0 right-0 z-20 bg-gradient-to-t from-black to-transparent h-24"></div>
    </div>
  );
}
