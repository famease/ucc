"use client";

import Image from "next/image";
import Link from "next/link";
import { Button } from "@/components/ui/button";
import {
  Card,
  CardContent,
  CardFooter,
  CardHeader,
  CardTitle,
} from "@/components/ui/card";

export function AboutUsSection() {
  return (
    <section className="py-16 bg-gray-50">
      <div className="container mx-auto px-4">
        <Card className="overflow-hidden">
          <div className="md:flex">
            <div className="md:w-1/2 relative h-64 md:h-auto">
              <Image
                src="/ucc-logo.jpg?height=600&width=800"
                alt="Our Church Community"
                layout="fill"
                objectFit="cover"
                className="rounded-t-lg md:rounded-l-lg md:rounded-t-none"
              />
            </div>
            <div className="md:w-1/2 p-6 md:p-8 flex flex-col justify-between">
              <div>
                <CardHeader className="p-0 mb-4">
                  <CardTitle className="text-3xl font-bold mb-2">
                    About Our Church
                  </CardTitle>
                </CardHeader>
                <CardContent className="p-0">
                  <p className="text-gray-600 mb-4">
                    Upper Room Christian Centre was established in 2003 by
                    Pastor David Moody and his wife, Myrtle Moody, under the
                    spiritual covering of Pastor Derek Adcock. From the
                    beginning, our church has been rooted in the heart of the
                    community, striving to create a family-oriented atmosphere
                    where everyone feels welcomed and valued. ✝️
                  </p>
                  <p className="text-gray-600 mb-4">
                    We are passionate about building strong relationships,
                    fostering spiritual growth, and sharing the love of Christ
                    with those around us. Our mission is to be a light in the
                    community, providing a place of hope, worship, and
                    transformation.
                  </p>
                </CardContent>
              </div>
              <CardFooter className="p-0">
                <Link href="/about" passHref>
                  <Button variant="outline" className="mt-4">
                    Learn More About Us
                  </Button>
                </Link>
              </CardFooter>
            </div>
          </div>
        </Card>
      </div>
    </section>
  );
}
