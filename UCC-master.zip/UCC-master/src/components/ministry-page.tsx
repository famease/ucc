'use client'

import Image from "next/image"
import { Button } from "@/components/ui/button"
import { Card, CardContent, CardDescription, CardFooter, CardHeader, CardTitle } from "@/components/ui/card"
import { Input } from "@/components/ui/input"
import { Textarea } from "@/components/ui/textarea"
import { Calendar, Mail, MapPin, Phone, Users } from "lucide-react"

export function MinistryPage() {
  return (
    <div className="min-h-screen bg-gray-100">
      <header className="bg-primary text-primary-foreground py-12 px-4 text-center">
        <h1 className="text-4xl font-bold mb-4">Youth Ministry</h1>
        <p className="max-w-2xl mx-auto text-lg">
          Empowering young people to grow in faith, fellowship, and service.
        </p>
      </header>

      <main className="container mx-auto px-4 py-8">
        <section className="mb-12">
          <h2 className="text-2xl font-semibold mb-4">About Our Ministry</h2>
          <p className="text-muted-foreground">
            Our Youth Ministry is dedicated to nurturing the spiritual growth of young people aged 13-18. 
            We provide a supportive environment where teens can explore their faith, build lasting friendships, 
            and develop leadership skills through various activities and service opportunities.
          </p>
        </section>

        {/* New Bento Grid Section */}
        <section className="mb-12">
          <h2 className="text-2xl font-semibold mb-6">Ministry in Action</h2>
          <div className="grid grid-cols-2 md:grid-cols-4 gap-4">
            <div className="col-span-2 row-span-2">
              <div className="relative h-full w-full overflow-hidden rounded-lg">
                <Image
                  src="/placeholder.svg?height=400&width=600"
                  alt="Youth group gathering"
                  layout="fill"
                  objectFit="cover"
                  className="transition-transform duration-300 hover:scale-105"
                />
                <div className="absolute bottom-0 left-0 right-0 bg-black bg-opacity-50 text-white p-2">
                  <p className="text-sm font-semibold">Youth Group Gathering</p>
                </div>
              </div>
            </div>
            <div className="col-span-1">
              <div className="relative h-40 w-full overflow-hidden rounded-lg">
                <Image
                  src="/placeholder.svg?height=200&width=200"
                  alt="Bible study"
                  layout="fill"
                  objectFit="cover"
                  className="transition-transform duration-300 hover:scale-105"
                />
                <div className="absolute bottom-0 left-0 right-0 bg-black bg-opacity-50 text-white p-2">
                  <p className="text-xs font-semibold">Bible Study</p>
                </div>
              </div>
            </div>
            <div className="col-span-1">
              <div className="relative h-40 w-full overflow-hidden rounded-lg">
                <Image
                  src="/placeholder.svg?height=200&width=200"
                  alt="Community service"
                  layout="fill"
                  objectFit="cover"
                  className="transition-transform duration-300 hover:scale-105"
                />
                <div className="absolute bottom-0 left-0 right-0 bg-black bg-opacity-50 text-white p-2">
                  <p className="text-xs font-semibold">Community Service</p>
                </div>
              </div>
            </div>
            <div className="col-span-1">
              <div className="relative h-40 w-full overflow-hidden rounded-lg">
                <Image
                  src="/placeholder.svg?height=200&width=200"
                  alt="Worship session"
                  layout="fill"
                  objectFit="cover"
                  className="transition-transform duration-300 hover:scale-105"
                />
                <div className="absolute bottom-0 left-0 right-0 bg-black bg-opacity-50 text-white p-2">
                  <p className="text-xs font-semibold">Worship Session</p>
                </div>
              </div>
            </div>
            <div className="col-span-1">
              <div className="relative h-40 w-full overflow-hidden rounded-lg">
                <Image
                  src="/placeholder.svg?height=200&width=200"
                  alt="Fun activities"
                  layout="fill"
                  objectFit="cover"
                  className="transition-transform duration-300 hover:scale-105"
                />
                <div className="absolute bottom-0 left-0 right-0 bg-black bg-opacity-50 text-white p-2">
                  <p className="text-xs font-semibold">Fun Activities</p>
                </div>
              </div>
            </div>
          </div>
        </section>

        <section className="grid md:grid-cols-3 gap-6 mb-12">
          <Card>
            <CardHeader>
              <CardTitle className="flex items-center">
                <Users className="mr-2" />
                Weekly Meetings
              </CardTitle>
            </CardHeader>
            <CardContent>
              <p>Every Saturday at 3PM - 5PM</p>
     <p>Every Sunday at 08:30AM - 10:15AM</p>
    
            </CardContent>
          </Card>
          <Card>
            <CardHeader>
              <CardTitle className="flex items-center">
                <MapPin className="mr-2" />
                Location
              </CardTitle>
            </CardHeader>
            <CardContent>
              <p>123 Church Street</p>
              <p>Anytown, ST 12345</p>
            </CardContent>
          </Card>
          <Card>
            <CardHeader>
              <CardTitle className="flex items-center">
                <Phone className="mr-2" />
                Contact
              </CardTitle>
            </CardHeader>
            <CardContent>
              <p>John Doe, Youth Pastor</p>
              <p>(555) 123-4567</p>
            </CardContent>
          </Card>
        </section>

        <section className="mb-12">
          <h2 className="text-2xl font-semibold mb-4">Upcoming Events</h2>
          <div className="grid md:grid-cols-2 gap-6">
            <Card>
              <CardHeader>
                <CardTitle>Summer Camp</CardTitle>
                <CardDescription className="flex items-center">
                  <Calendar className="mr-2" />
                  July 15-22, 2023
                </CardDescription>
              </CardHeader>
              <CardContent>
                <p>Join us for a week of fun, fellowship, and spiritual growth at Lake Awesome!</p>
              </CardContent>
              <CardFooter>
                <Button>Learn More</Button>
              </CardFooter>
            </Card>
            <Card>
              <CardHeader>
                <CardTitle>Community Service Day</CardTitle>
                <CardDescription className="flex items-center">
                  <Calendar className="mr-2" />
                  August 5, 2023
                </CardDescription>
              </CardHeader>
              <CardContent>
                <p>Help make a difference in our community by participating in various service projects.</p>
              </CardContent>
              <CardFooter>
                <Button>Sign Up</Button>
              </CardFooter>
            </Card>
          </div>
        </section>

        <section className="mb-12">
          <h2 className="text-2xl font-semibold mb-4">Get in Touch</h2>
          <Card>
            <CardHeader>
              <CardTitle>Contact Us</CardTitle>
              <CardDescription>Have questions or want to get involved? Reach out to us!</CardDescription>
            </CardHeader>
            <CardContent>
              <form className="space-y-4">
                <div className="grid md:grid-cols-2 gap-4">
                  <Input placeholder="First Name" />
                  <Input placeholder="Last Name" />
                </div>
                <Input type="email" placeholder="Email" />
                <Textarea placeholder="Your message" />
                <Button type="submit" className="w-full">Send Message</Button>
              </form>
            </CardContent>
          </Card>
        </section>
      </main>

      <footer className="bg-gray-200 py-6 px-4">
        <div className="container mx-auto text-center">
          <p className="text-muted-foreground mb-4">© 2023 Your Church Name. All rights reserved.</p>
          <nav className="flex justify-center space-x-4">
            <a href="#" className="text-primary hover:underline">Home</a>
            <a href="#" className="text-primary hover:underline">About</a>
            <a href="#" className="text-primary hover:underline">Ministries</a>
            <a href="#" className="text-primary hover:underline">Events</a>
            <a href="#" className="text-primary hover:underline">Contact</a>
          </nav>
        </div>
      </footer>
    </div>
  )
}