"use client";

import { useState, useEffect, useCallback } from "react";
import Image from "next/image";
import Link from "next/link";
import { Card, CardContent } from "@/components/ui/card";
import {
  Carousel,
  CarouselContent,
  CarouselItem,
  CarouselNext,
  CarouselPrevious,
} from "@/components/ui/carousel";
import { useMediaQuery } from "@/hooks/use-media-query";
import { motion } from "framer-motion";
import { ChevronRight } from "lucide-react";
import { ministries } from "@/types/ministry";

export function MinistriesCarousel() {
  const [api, setApi] = useState<any>();
  const [current, setCurrent] = useState(0);
  const [count, setCount] = useState(0);
  const isMobile = useMediaQuery("(max-width: 768px)");
  const isTablet = useMediaQuery("(min-width: 769px) and (max-width: 1024px)");

  useEffect(() => {
    if (!api) {
      return;
    }

    setCount(api.scrollSnapList().length);
    setCurrent(api.selectedScrollSnap());

    api.on("select", () => {
      setCurrent(api.selectedScrollSnap());
    });
  }, [api]);

  const scrollTo = useCallback(
    (index: number) => {
      api?.scrollTo(index);
    },
    [api]
  );

  const itemsPerView = isMobile ? 1 : isTablet ? 2 : 3;

  return (
    <section className="py-16 bg-gray-100">
      <div className="container mx-auto px-4">
        <h2 className="text-3xl md:text-4xl font-bold text-center mb-8">
          Our Ministries
        </h2>
        <p className="text-xl text-center text-gray-600 mb-12 max-w-3xl mx-auto">
          Explore the various ways you can get involved and grow in your faith
          journey with us.
        </p>
        <div className="relative">
          <Carousel
            setApi={setApi}
            opts={{
              align: "start",
              loop: true,
            }}
            className="w-full max-w-5xl mx-auto"
          >
            <CarouselContent>
              {ministries.map((ministry, index) => (
                <CarouselItem key={index} className="md:basis-1/2 lg:basis-1/3">
                  <Link href={ministry.link}>
                    <Card className="overflow-hidden transition-all duration-300 hover:shadow-lg hover:scale-105">
                      <CardContent className="p-0">
                        <div className="relative h-48 group">
                          <Image
                            src={ministry.image}
                            alt={ministry.name}
                            layout="fill"
                            objectFit="cover"
                          />
                          <div className="absolute inset-0 bg-black bg-opacity-40 transition-opacity duration-300 opacity-0 group-hover:opacity-100 flex items-center justify-center">
                            <span className="text-white text-lg font-semibold">
                              Learn More
                            </span>
                          </div>
                        </div>
                        <h3 className="text-xl font-semibold p-4 text-center group-hover:text-primary transition-colors duration-300">
                          {ministry.name}
                        </h3>
                      </CardContent>
                    </Card>
                  </Link>
                </CarouselItem>
              ))}
            </CarouselContent>
            <div className="container hidden md:block">
              <CarouselPrevious />
              <CarouselNext />
            </div>
          </Carousel>
          {/* <motion.div
            className="absolute right-4 top-1/2 -translate-y-1/2 text-primary"
            animate={{ x: [0, 10, 0] }}
            transition={{ repeat: Infinity, duration: 1.5 }}
          >
            <ChevronRight size={32} />
          </motion.div> */}
        </div>
        <div className="flex justify-center mt-4 space-x-2">
          {Array.from({ length: Math.ceil(count / itemsPerView) }).map(
            (_, index) => (
              <button
                key={index}
                className={`w-3 h-3 rounded-full ${
                  Math.floor(current / itemsPerView) === index
                    ? "bg-primary"
                    : "bg-gray-300"
                }`}
                onClick={() => scrollTo(index * itemsPerView)}
              />
            )
          )}
        </div>
        <div className="flex justify-center mt-8">
          <Link href="/ministries">
            <button className="px-6 py-2 bg-primary text-white rounded hover:bg-primary-dark transition duration-300">
              View All
            </button>
          </Link>
        </div>
      </div>
    </section>
  );
}
