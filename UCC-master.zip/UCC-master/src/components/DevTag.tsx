"use client";

import { RiGithubFill, RiGlobalLine, RiWhatsappFill } from "@remixicon/react";
import Link from "next/link";
import Image from "next/image";

export function CreatorBannerComponent() {
  return (
    <div className="bg-gray-900 text-white p-4 shadow-lg">
      <div className="container mx-auto flex flex-col sm:flex-row items-center justify-between">
        <div className="flex items-center mb-4 sm:mb-0">
          <Image
            src="https://avatars.githubusercontent.com/u/120386361?v=4?height=40&width=40"
            alt="Creator Avatar"
            className="w-10 h-10 rounded-full mr-4 border-2 border-white"
            width={40}
            height={40}
          />
          <div>
            <h2 className="text-xl font-bold">Created by Tshebo Sereetsi</h2>
            <p className="text-sm text-gray-300">
              Full-stack Developer & Designer
            </p>
          </div>
        </div>
        <div className="flex space-x-4">
          <Link
            href="https://tshebo.co.za"
            target="_blank"
            rel="noopener noreferrer"
            className="hover:text-gray-300 transition-colors duration-200"
            aria-label="Website"
          >
            <RiGlobalLine className="w-6 h-6" />
          </Link>
          <Link
            href="https://github.com/tshebo"
            target="_blank"
            rel="noopener noreferrer"
            className="hover:text-gray-300 transition-colors duration-200"
            aria-label="GitHub Profile"
          >
            <RiGithubFill className="w-6 h-6" />
          </Link>
          <Link
            href="https://wa.me/+27818578249"
            target="_blank"
            rel="noopener noreferrer"
            className="hover:text-gray-300 transition-colors duration-200"
            aria-label="WhatsApp Contact"
          >
            <RiWhatsappFill className="w-6 h-6" />
          </Link>
        </div>
      </div>
    </div>
  );
}
