"use client";

import Link from "next/link";
import { usePathname } from "next/navigation";
import { BookOpen, Calendar, Menu } from "lucide-react";

import { cn } from "@/lib/utils";
import { Button } from "@/components/ui/button";
import { Sheet, SheetContent, SheetTrigger } from "@/components/ui/sheet";
import { UserButton } from "@clerk/nextjs";

const navItems = [
  { name: "Blog", href: "/admin/blog", icon: BookOpen },
  { name: "Events", href: "/admin/events", icon: Calendar },
];

export function AdminTopNavComponent() {
  const pathname = usePathname();

  const NavContent = () => (
    <div className="flex items-center space-x-4">
      <h2 className="text-lg font-semibold tracking-tight mr-4">
        Admin Dashboard
      </h2>
      <div className="flex space-x-1">
        {navItems.map((item) => (
          <Button
            key={item.name}
            asChild
            variant={pathname === item.href ? "secondary" : "ghost"}
            className="flex items-center"
          >
            <Link href={item.href}>
              <item.icon className="mr-2 h-5 w-5" />
              {item.name}
            </Link>
          </Button>
        ))}
      </div>
    </div>
  );

  return (
    <nav className="bg-white border-b">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="flex justify-between h-16">
          <div className="flex">
            <div className="hidden md:flex md:items-center">
              <NavContent />
            </div>
          </div>
          <div className="flex items-center">
            <UserButton />
            <span className="ml-2 hidden md:inline">Profile</span>
          </div>
          <div className="flex items-center md:hidden">
            <Sheet>
              <SheetTrigger asChild>
                <Button variant="outline" size="icon" className="ml-2">
                  <Menu className="h-6 w-6" />
                  <span className="sr-only">Toggle navigation menu</span>
                </Button>
              </SheetTrigger>
              <SheetContent side="right" className="w-[240px] sm:w-[300px] p-0">
                <div className="py-4 px-4">
                  <NavContent />
                  <div className="mt-4 flex items-center">
                    <UserButton />
                    <span className="ml-2">Profile</span>
                  </div>
                </div>
              </SheetContent>
            </Sheet>
          </div>
        </div>
      </div>
    </nav>
  );
}
