"use client";

import { useState } from "react";
import Image from "next/image";
import { format } from "date-fns";
import { Calendar, Clock, MapPin } from "lucide-react";
import { Button } from "@/components/ui/button";
import { Card, CardContent } from "@/components/ui/card";
import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogHeader,
  DialogTitle,
  DialogTrigger,
} from "@/components/ui/dialog";
import { toast } from "@/components/ui/use-toast";

type Event = {
  id: number;
  title: string;
  date: Date;
  time: string;
  location: string;
  description: string;
  image: string;
};

const events: Event[] = [
  {
    id: 1,
    title: "Summer Bible Camp",
    date: new Date(2023, 6, 15),
    time: "9:00 AM - 3:00 PM",
    location: "Church Grounds",
    description:
      "Join us for a week of fun, learning, and spiritual growth at our annual Summer Bible Camp. Activities include Bible studies, games, crafts, and more!",
    image: "/placeholder.svg?height=400&width=600",
  },
  {
    id: 2,
    title: "Community Outreach Day",
    date: new Date(2023, 7, 5),
    time: "10:00 AM - 2:00 PM",
    location: "City Park",
    description:
      "Help us make a difference in our community! We'll be cleaning up the park, planting trees, and hosting a free lunch for all volunteers.",
    image: "/placeholder.svg?height=400&width=600",
  },
  {
    id: 3,
    title: "Worship Night",
    date: new Date(2023, 7, 20),
    time: "7:00 PM - 9:00 PM",
    location: "Main Sanctuary",
    description:
      "Experience an evening of powerful worship and prayer. Join us as we come together to praise and seek God's presence.",
    image: "/placeholder.svg?height=400&width=600",
  },
];

export function UpcomingEvents() {
  const [selectedEvent, setSelectedEvent] = useState<Event | null>(null);

  const handleSetReminder = (event: Event) => {
    // In a real application, this would integrate with a calendar API or notification system
    toast({
      title: "Reminder Set",
      description: `You'll be reminded about "${event.title}" on ${format(
        event.date,
        "MMMM d, yyyy"
      )} at ${event.time}.`,
    });
  };

  return (
    <section className="py-16 bg-gray-50">
      <div className="container mx-auto px-4">
        <h2 className="text-3xl md:text-4xl font-bold text-center mb-8">
          Upcoming Events
        </h2>
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-8">
          {events.map((event) => (
            <Card key={event.id} className="overflow-hidden">
              <CardContent className="p-0">
                <Image
                  src={event.image}
                  alt={event.title}
                  width={600}
                  height={400}
                  className="w-full h-48 object-cover"
                />
                <div className="p-4">
                  <h3 className="text-xl font-semibold mb-2">{event.title}</h3>
                  <div className="flex items-center text-gray-600 mb-2">
                    <Calendar className="w-4 h-4 mr-2" />
                    <span>{format(event.date, "MMMM d, yyyy")}</span>
                  </div>
                  <div className="flex items-center text-gray-600 mb-4">
                    <Clock className="w-4 h-4 mr-2" />
                    <span>{event.time}</span>
                  </div>
                  <Dialog>
                    <DialogTrigger asChild>
                      <Button
                        variant="outline"
                        className="w-full"
                        onClick={() => setSelectedEvent(event)}
                      >
                        View Details
                      </Button>
                    </DialogTrigger>
                    <DialogContent className="sm:max-w-[425px]">
                      <DialogHeader>
                        <DialogTitle>{selectedEvent?.title}</DialogTitle>
                        <DialogDescription>
                          {format(
                            selectedEvent?.date || new Date(),
                            "MMMM d, yyyy"
                          )}{" "}
                          at {selectedEvent?.time}
                        </DialogDescription>
                      </DialogHeader>
                      <div className="grid gap-4 py-4">
                        <Image
                          src={selectedEvent?.image || ""}
                          alt={selectedEvent?.title || ""}
                          width={600}
                          height={400}
                          className="w-full h-48 object-cover rounded-md"
                        />
                        <p className="text-gray-700">
                          {selectedEvent?.description}
                        </p>
                        <div className="flex items-center text-gray-600">
                          <MapPin className="w-4 h-4 mr-2" />
                          <span>{selectedEvent?.location}</span>
                        </div>
                      </div>
                      <Button
                        onClick={() =>
                          selectedEvent && handleSetReminder(selectedEvent)
                        }
                      >
                        Set Reminder
                      </Button>
                    </DialogContent>
                  </Dialog>
                </div>
              </CardContent>
            </Card>
          ))}
        </div>
      </div>
    </section>
  );
}
