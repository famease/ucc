"use client";

import Image from "next/image";
import Link from "next/link";
import {
  ArrowRight,
  Calendar,
  MapPin,
  Music,
  Book,
  Heart,
  Users,
} from "lucide-react";

import { Button } from "@/components/ui/button";
import { Card, CardContent } from "@/components/ui/card";

export function MinistryShowcaseComponent() {
  return (
    <div></div>
    // <div className="container mx-auto px-4 py-8">
    //   <h1 className="text-4xl font-bold text-center mb-8">Youth Ministry</h1>

    //   {/* Introductory Section */}
    //   <div className="mb-12 text-center max-w-3xl mx-auto">
    //     <p className="text-xl mb-4">
    //       Welcome to our vibrant Youth Ministry! We&apos;re dedicated to
    //       nurturing the faith, character, and leadership skills of young people
    //       in our community.
    //     </p>
    //     <p className="text-lg text-muted-foreground">
    //       Through engaging activities, meaningful worship, and supportive
    //       fellowship, we aim to empower the next generation to live out their
    //       faith boldly and make a positive impact in the world.
    //     </p>
    //   </div>

    //   {/* Bento Grid of Images */}
    //   <div className="grid grid-cols-1 md:grid-cols-3 gap-4 mb-8 ">
    //     <Image
    //       src="/placeholder.svg?height=300&width=400"
    //       alt="Youth event 1"
    //       width={400}
    //       height={300}
    //       className="rounded-lg object-cover w-full h-full"
    //     />
    //     <Image
    //       src="/placeholder.svg?height=300&width=400"
    //       alt="Youth event 2"
    //       width={400}
    //       height={300}
    //       className="rounded-lg object-cover w-full h-full"
    //     />
    //     <Image
    //       src="/placeholder.svg?height=300&width=400"
    //       alt="Youth event 3"
    //       width={400}
    //       height={300}
    //       className="rounded-lg object-cover w-full h-full md:col-span-1 md:row-span-2"
    //     />
    //     <Image
    //       src="/placeholder.svg?height=300&width=400"
    //       alt="Youth event 4"
    //       width={400}
    //       height={300}
    //       className="rounded-lg object-cover w-full h-full"
    //     />
    //     <Image
    //       src="/placeholder.svg?height=300&width=400"
    //       alt="Youth event 5"
    //       width={400}
    //       height={300}
    //       className="rounded-lg object-cover w-full h-full"
    //     />
    //   </div>

    //   {/* Gallery Link */}
    //   <div className="text-center mb-12">
    //     <Button asChild>
    //       <Link href="/gallery">
    //         View Full Gallery
    //         <ArrowRight className="ml-2 h-4 w-4" />
    //       </Link>
    //     </Button>
    //   </div>

    //   {/* Leadership Section */}
    //   <h2 className="text-3xl font-semibold mb-6 text-center">
    //     Our Leadership Team
    //   </h2>
    //   <div className="grid md:grid-cols-3 gap-8 mb-12">
    //     <Card className="overflow-hidden">
    //       <Image
    //         src="/placeholder.svg?height=300&width=300"
    //         alt="John Doe"
    //         width={300}
    //         height={300}
    //         className="w-full h-48 object-cover"
    //       />
    //       <CardContent className="p-4">
    //         <h3 className="text-xl font-semibold mb-2">John Doe</h3>
    //         <p className="text-muted-foreground">Youth Pastor</p>
    //       </CardContent>
    //     </Card>
    //     <Card className="overflow-hidden">
    //       <Image
    //         src="/placeholder.svg?height=300&width=300"
    //         alt="Jane Smith"
    //         width={300}
    //         height={300}
    //         className="w-full h-48 object-cover"
    //       />
    //       <CardContent className="p-4">
    //         <h3 className="text-xl font-semibold mb-2">Jane Smith</h3>
    //         <p className="text-muted-foreground">Assistant Youth Leader</p>
    //       </CardContent>
    //     </Card>
    //     <Card className="overflow-hidden">
    //       <Image
    //         src="/placeholder.svg?height=300&width=300"
    //         alt="Mike Johnson"
    //         width={300}
    //         height={300}
    //         className="w-full h-48 object-cover"
    //       />
    //       <CardContent className="p-4">
    //         <h3 className="text-xl font-semibold mb-2">Mike Johnson</h3>
    //         <p className="text-muted-foreground">Worship Coordinator</p>
    //       </CardContent>
    //     </Card>
    //   </div>

    //   {/* Activities Journey */}
    //   <h2 className="text-3xl font-semibold mb-6 text-center">
    //     Our Ministry Journey
    //   </h2>
    //   <div className="space-y-12 relative before:absolute before:inset-0 before:ml-5 before:h-full before:w-0.5 before:-translate-x-px before:bg-gradient-to-b before:from-transparent before:via-slate-300 before:to-transparent">
    //     <div className="relative flex items-center justify-between md:justify-normal md:odd:flex-row-reverse group is-active">
    //       <div className="flex items-center justify-center w-10 h-10 rounded-full border border-white bg-slate-300 group-[.is-active]:bg-emerald-500 text-slate-500 group-[.is-active]:text-emerald-50 shadow shrink-0 md:order-1 md:group-odd:-translate-x-1/2 md:group-even:translate-x-1/2">
    //         <Calendar className="w-4 h-4" />
    //       </div>
    //       <div className="w-[calc(100%-4rem)] md:w-[calc(50%-2.5rem)] bg-white p-4 rounded shadow">
    //         <h3 className="text-xl font-semibold mb-2">Weekly Youth Service</h3>
    //         <p className="text-muted-foreground">
    //           Every Sunday at 6 PM, join us for worship, teaching, and
    //           fellowship.
    //         </p>
    //       </div>
    //     </div>
    //     <div className="relative flex items-center justify-between md:justify-normal md:odd:flex-row-reverse group is-active">
    //       <div className="flex items-center justify-center w-10 h-10 rounded-full border border-white bg-slate-300 group-[.is-active]:bg-emerald-500 text-slate-500 group-[.is-active]:text-emerald-50 shadow shrink-0 md:order-1 md:group-odd:-translate-x-1/2 md:group-even:translate-x-1/2">
    //         <Book className="w-4 h-4" />
    //       </div>
    //       <div className="w-[calc(100%-4rem)] md:w-[calc(50%-2.5rem)] bg-white p-4 rounded shadow">
    //         <h3 className="text-xl font-semibold mb-2">
    //           Small Group Bible Studies
    //         </h3>
    //         <p className="text-muted-foreground">
    //           Wednesdays at 7 PM, dive deeper into God's Word in a more intimate
    //           setting.
    //         </p>
    //       </div>
    //     </div>
    //     <div className="relative flex items-center justify-between md:justify-normal md:odd:flex-row-reverse group is-active">
    //       <div className="flex items-center justify-center w-10 h-10 rounded-full border border-white bg-slate-300 group-[.is-active]:bg-emerald-500 text-slate-500 group-[.is-active]:text-emerald-50 shadow shrink-0 md:order-1 md:group-odd:-translate-x-1/2 md:group-even:translate-x-1/2">
    //         <Heart className="w-4 h-4" />
    //       </div>
    //       <div className="w-[calc(100%-4rem)] md:w-[calc(50%-2.5rem)] bg-white p-4 rounded shadow">
    //         <h3 className="text-xl font-semibold mb-2">
    //           Monthly Outreach Programs
    //         </h3>
    //         <p className="text-muted-foreground">
    //           Serve our community and share God&apos;s love through various
    //           outreach activities.
    //         </p>
    //       </div>
    //     </div>
    //     <div className="relative flex items-center justify-between md:justify-normal md:odd:flex-row-reverse group is-active">
    //       <div className="flex items-center justify-center w-10 h-10 rounded-full border border-white bg-slate-300 group-[.is-active]:bg-emerald-500 text-slate-500 group-[.is-active]:text-emerald-50 shadow shrink-0 md:order-1 md:group-odd:-translate-x-1/2 md:group-even:translate-x-1/2">
    //         <MapPin className="w-4 h-4" />
    //       </div>
    //       <div className="w-[calc(100%-4rem)] md:w-[calc(50%-2.5rem)] bg-white p-4 rounded shadow">
    //         <h3 className="text-xl font-semibold mb-2">Annual Youth Camp</h3>
    //         <p className="text-muted-foreground">
    //           Join us every summer for an unforgettable week of spiritual growth
    //           and adventure.
    //         </p>
    //       </div>
    //     </div>
    //     <div className="relative flex items-center justify-between md:justify-normal md:odd:flex-row-reverse group is-active">
    //       <div className="flex items-center justify-center w-10 h-10 rounded-full border border-white bg-slate-300 group-[.is-active]:bg-emerald-500 text-slate-500 group-[.is-active]:text-emerald-50 shadow shrink-0 md:order-1 md:group-odd:-translate-x-1/2 md:group-even:translate-x-1/2">
    //         <Users className="w-4 h-4" />
    //       </div>
    //       <div className="w-[calc(100%-4rem)] md:w-[calc(50%-2.5rem)] bg-white p-4 rounded shadow">
    //         <h3 className="text-xl font-semibold mb-2">
    //           Quarterly Parent-Youth Fellowship
    //         </h3>
    //         <p className="text-muted-foreground">
    //           Strengthen family bonds and build a supportive community together.
    //         </p>
    //       </div>
    //     </div>
    //   </div>
    // </div>
  );
}
