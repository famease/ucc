import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card'

export default function ContactInfo() {
  return (
    <Card className="mt-8">
      <CardHeader>
        <CardTitle>Contact Us</CardTitle>
      </CardHeader>
      <CardContent>
        <div className="space-y-2">
          <p><strong>Address:</strong> 2-4 Reeders St, Haddon, JHB South 2190</p>
          <p><strong>Phone:</strong> 011 683 0075</p>
          <p><strong>Email:</strong> uccjhbsouth@gmail.com</p>
          <p><strong>Office Hours:</strong> Monday - Sunday, 9:00 AM - 5:00 PM</p>
        </div>
      </CardContent>
    </Card>
  )
}

