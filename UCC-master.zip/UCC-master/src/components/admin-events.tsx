// "use client";

// import { useState } from "react";
// import Link from "next/link";
// import { format } from "date-fns";
// import { Edit, Trash2, Plus, Calendar, Clock } from "lucide-react";
// import { Button } from "@/components/ui/button";
// import {
//   Card,
//   CardContent,
//   CardFooter,
//   CardHeader,
//   CardTitle,
// } from "@/components/ui/card";
// import {
//   AlertDialog,
//   AlertDialogAction,
//   AlertDialogCancel,
//   AlertDialogContent,
//   AlertDialogDescription,
//   AlertDialogFooter,
//   AlertDialogHeader,
//   AlertDialogTitle,
// } from "@/components/ui/alert-dialog";

// // Dummy data for events
// const dummyEvents = [
//   {
//     id: 1,
//     title: "Summer Youth Camp",
//     poster: "/placeholder.svg?height=100&width=100",
//     date: "2023-07-15",
//     startTime: "09:00",
//     endTime: "17:00",
//     description: "Annual summer camp for youth",
//     ministry: "Youth Ministry",
//     setReminder: true,
//   },
//   {
//     id: 2,
//     title: "Christmas Eve Service",
//     poster: "/placeholder.svg?height=100&width=100",
//     date: "2023-12-24",
//     startTime: "19:00",
//     endTime: "21:00",
//     description: "Special Christmas Eve worship service",
//     ministry: "Worship Ministry",
//     setReminder: false,
//   },
//   {
//     id: 3,
//     title: "Easter Sunday Celebration",
//     poster: "/placeholder.svg?height=100&width=100",
//     date: "2024-04-21",
//     startTime: "10:00",
//     endTime: "12:00",
//     description: "Joyful Easter Sunday service",
//     ministry: "Worship Ministry",
//     setReminder: true,
//   },
// ];

// export function AdminEvents() {
//   const [events, setEvents] = useState(dummyEvents);
//   const [deleteEvent, setDeleteEvent] = useState(null);

//   const handleDeleteEvent = (id:any) => {
//     setEvents(events.filter((event) => event.id !== id));
//     setDeleteEvent(null);
//   };

//   return (
//     <div className="container mx-auto py-10">
//       <div className="flex justify-between items-center mb-6">
//         <h1 className="text-3xl font-bold">Upcoming Events</h1>
//         <Button asChild>
//           <Link href="/admin/events/add">
//             <Plus className="mr-2 h-4 w-4" /> Add New Event
//           </Link>
//         </Button>
//       </div>

//       <div className="grid gap-4 sm:grid-cols-2 lg:grid-cols-3 xl:grid-cols-4">
//         {events
//           .sort((a, b) => new Date(b.date) - new Date(a.date))
//           .map((event) => (
//             <Card key={event.id} className="flex flex-col">
//               <CardHeader className="p-4">
//                 <CardTitle className="text-lg">{event.title}</CardTitle>
//               </CardHeader>
//               <CardContent className="p-4 pt-0 flex-grow">
//                 <img
//                   src={event.poster}
//                   alt={event.title}
//                   className="w-full h-32 object-cover mb-3 rounded"
//                 />
//                 <div className="space-y-1 text-sm">
//                   <p className="flex items-center">
//                     <Calendar className="mr-2 h-4 w-4" />
//                     {format(new Date(event.date), "MMM d, yyyy")}
//                   </p>
//                   <p className="flex items-center">
//                     <Clock className="mr-2 h-4 w-4" />
//                     {event.startTime} - {event.endTime}
//                   </p>
//                   <p className="font-medium">{event.ministry}</p>
//                 </div>
//               </CardContent>
//               <CardFooter className="p-4 pt-0 flex justify-between">
//                 <Button variant="outline" size="sm" asChild>
//                   <Link href={`/admin/events/edit/${event.id}`}>
//                     <Edit className="mr-2 h-3 w-3" /> Edit
//                   </Link>
//                 </Button>
//                 <Button
//                   variant="destructive"
//                   size="sm"
//                   onClick={() => setDeleteEvent(event)}
//                 >
//                   <Trash2 className="mr-2 h-3 w-3" /> Delete
//                 </Button>
//               </CardFooter>
//             </Card>
//           ))}
//       </div>

//       <AlertDialog
//         open={!!deleteEvent}
//         onOpenChange={() => setDeleteEvent(null)}
//       >
//         <AlertDialogContent>
//           <AlertDialogHeader>
//             <AlertDialogTitle>
//               Are you sure you want to delete this event?
//             </AlertDialogTitle>
//             <AlertDialogDescription>
//               This action cannot be undone. This will permanently delete the
//               event "{deleteEvent?.title}" and remove it from our servers.
//             </AlertDialogDescription>
//           </AlertDialogHeader>
//           <AlertDialogFooter>
//             <AlertDialogCancel>Cancel</AlertDialogCancel>
//             <AlertDialogAction
//               onClick={() => handleDeleteEvent(deleteEvent.id)}
//             >
//               Delete
//             </AlertDialogAction>
//           </AlertDialogFooter>
//         </AlertDialogContent>
//       </AlertDialog>
//     </div>
//   );
// }
