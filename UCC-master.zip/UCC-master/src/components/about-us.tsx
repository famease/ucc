"use client";
import Image from "next/image";
import Link from "next/link";
import {
  Card,
  CardContent,
  CardDescription,
  CardHeader,
  CardTitle,
} from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import {
  Clock,
  MapPin,
  Phone,
  Mail,
  Facebook,
  Instagram,
  Youtube,
  Podcast,
  ChevronRight,
} from "lucide-react";

export default function AboutUs() {
  return (
    <div className="min-h-screen bg-gray-100">
      <header className="bg-primary text-primary-foreground py-8 relative">
        <Image
          src="/cross.webp?height=400&width=1920"
          alt="Church building"
          width={1920}
          height={400}
          className="absolute inset-0 w-full h-full object-cover mix-blend-overlay"
        />
        <div className="container mx-auto text-center relative z-10">
          <h1 className="text-4xl font-bold">Upperroom Christian Center</h1>
        </div>
      </header>

      <main className="container mx-auto py-8 px-4">
        <section className="mb-12 flex flex-col md:flex-row items-center gap-8">
          <div className="md:w-1/2">
            <h2 className="text-3xl font-semibold mb-4">
              Welcome to Upperroom Christian Center
            </h2>
            <p className="text-lg">
              We are a vibrant, inclusive community of believers dedicated to
              spreading God&apos;s love and grace. Our church is a place where
              everyone is welcome, regardless of their background or where they
              are on their spiritual journey.
            </p>
          </div>
          <div className="md:w-1/2">
            <Image
              src="/ucc-logo.jpg?height=400&width=600"
              alt="Church congregation"
              width={600}
              height={400}
              className="rounded-lg shadow-lg"
            />
          </div>
        </section>

        <section className="mb-12">
          <h2 className="text-3xl font-semibold mb-4">Our Mission & Values</h2>
          <p className="text-lg mb-4">
            Our mission is to love God, love others, and make disciples. We
            strive to create a community where faith can flourish and where we
            can make a positive impact in our local area and beyond.
          </p>
          <ul className="grid grid-cols-1 md:grid-cols-2 gap-4 text-lg">
            <li className="flex items-center">
              <div className="bg-primary text-primary-foreground rounded-full p-2 mr-2">
                <ChevronRight className="h-4 w-4" />
              </div>
              Faith: Deepening our relationship with God
            </li>
            <li className="flex items-center">
              <div className="bg-primary text-primary-foreground rounded-full p-2 mr-2">
                <ChevronRight className="h-4 w-4" />
              </div>
              Community: Building strong, supportive relationships
            </li>
            <li className="flex items-center">
              <div className="bg-primary text-primary-foreground rounded-full p-2 mr-2">
                <ChevronRight className="h-4 w-4" />
              </div>
              Service: Reaching out to those in need
            </li>
            <li className="flex items-center">
              <div className="bg-primary text-primary-foreground rounded-full p-2 mr-2">
                <ChevronRight className="h-4 w-4" />
              </div>
              Growth: Continual learning and spiritual development
            </li>
          </ul>
        </section>

        <section className="mb-12">
          <h2 className="text-3xl font-semibold mb-6">Our Ministries</h2>
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
            {[
              {
                title: "One2Nine Generation",
                image: "/youth1.webp?height=300&width=400",
                link: "/ministries/youth",
                description:
                  "Empowering the next generation to live out their faith boldly through dynamic events, community involvement, and spiritual growth.",
              },
              {
                title: "UCC Missions",
                image: "/missions1.webp?height=300&width=400",
                link: "/ministries/missions",
                description:
                  "Serving our communities with compassion, spreading hope, and making a tangible difference through various outreach initiatives.",
              },
              {
                title: "Women of valor",
                image: "/women.webp?height=300&width=400",
                link: "/ministries/wov",
                description:
                  "A vibrant community for women to connect, support one another, and grow in faith, courage, and wisdom.",
              },
              {
                title: "Brothers Ministry",
                image: "/brothers.webp?height=300&width=400",
                link: "/ministries/brothers",
                description:
                  "Bringing men together for fellowship, personal growth, and leadership in the community, guided by faith and brotherhood.",
              },
              {
                title: "Celebrate Recovery",
                image: "/cr-group.webp?height=300&width=400",
                link: "/ministries/cr",
                description:
                  "A safe place for those seeking healing and recovery, offering support and encouragement through faith-based programs.",
              },
              {
                title: "Sunday School",
                image: "/sunday-school.webp?height=300&width=400",
                link: "/ministries/sunday-school",
                description:
                  "Engaging children with fun and meaningful lessons that help them understand God's love and grow in their spiritual journey.",
              },
            ].map((ministry, index) => (
              <Card key={index}>
                <Image
                  src={ministry.image}
                  alt={ministry.title}
                  width={300}
                  height={200}
                  className="w-full h-48 object-cover rounded-t-lg"
                />
                <CardHeader>
                  <CardTitle>{ministry.title}</CardTitle>
                </CardHeader>
                <CardContent>
                  <CardDescription>{ministry.description}</CardDescription>
                  <Link
                    href={`${ministry.link}`}
                    className="inline-flex items-center mt-2 text-primary hover:underline"
                  >
                    Learn More <ChevronRight className="ml-1 h-4 w-4" />
                  </Link>
                </CardContent>
              </Card>
            ))}
          </div>
        </section>

        <section className="mb-12">
          <h2 className="text-3xl font-semibold mb-6">Join Us</h2>
          <Card>
            <CardContent className="pt-6">
              <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                <div className="flex items-center">
                  <Clock className="mr-2 text-primary" />
                  <p>Sunday Services: 8:00 AM & 10:00 AM</p>
                </div>
                <div className="flex items-center">
                  <MapPin className="mr-2 text-primary" />
                  <p> 2-4 Reeders St, Haddon, JHB South 2190</p>
                </div>
                <div className="flex items-center">
                  <Phone className="mr-2 text-primary" />
                  <p>011 683 0075</p>
                </div>
                <div className="flex items-center">
                  <Mail className="mr-2 text-primary" />
                  <p>uccjhbsouth@gmail.com</p>
                </div>
              </div>
            </CardContent>
          </Card>
        </section>

        {/* <section className="mb-12">
          <h2 className="text-3xl font-semibold mb-6">Upcoming Events</h2>
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
            {[
              { title: "Summer Bible Camp", date: "July 15-20, 2024", image: "/placeholder.svg?height=200&width=300" },
              { title: "Community Outreach Day", date: "August 5, 2024", image: "/placeholder.svg?height=200&width=300" },
              { title: "Worship Night", date: "August 18, 2024", image: "/placeholder.svg?height=200&width=300" },
            ].map((event, index) => (
              <Card key={index}>
                <Image
                  src={event.image}
                  alt={event.title}
                  width={300}
                  height={200}
                  className="w-full h-48 object-cover rounded-t-lg"
                />
                <CardHeader>
                  <CardTitle>{event.title}</CardTitle>
                  <CardDescription>{event.date}</CardDescription>
                </CardHeader>
                <CardContent>
                  <Link href="/events" className="inline-flex items-center text-primary hover:underline">
                    View Details <ChevronRight className="ml-1 h-4 w-4" />
                  </Link>
                </CardContent>
              </Card>
            ))}
          </div>
          <div className="text-center mt-6">
            <Button asChild>
              <Link href="/events">View All Events</Link>
            </Button>
          </div>
        </section> */}

        <section>
          <h2 className="text-3xl font-semibold mb-6">Get Involved</h2>
          <p className="text-lg mb-4">
            We&apos;d love for you to become a part of our church family.
            Whether you&apos;re interested in attending a service, joining a
            ministry, or simply learning more about our community, we&apos;re
            here to welcome you.
          </p>
          <Button asChild size="lg">
            <Link href="/contact">Contact Us</Link>
          </Button>
        </section>
      </main>

      {/* <footer className="bg-gray-200 py-8 mt-12">
        <div className="container mx-auto px-4">
          <div className="flex flex-wrap justify-between">
            <div className="w-full md:w-1/4 mb-6 md:mb-0">
              <h3 className="text-lg font-semibold mb-2">Quick Links</h3>
              <ul className="space-y-2">
                <li><Link href="/" className="hover:underline">Home</Link></li>
                <li><Link href="/events" className="hover:underline">Events</Link></li>
                <li><Link href="/sermons" className="hover:underline">Sermons</Link></li>
                <li><Link href="/give" className="hover:underline">Give</Link></li>
              </ul>
            </div>
            <div className="w-full md:w-1/4 mb-6 md:mb-0">
              <h3 className="text-lg font-semibold mb-2">Connect</h3>
              <ul className="space-y-2">
                <li><a href="#" className="hover:underline flex items-center"><Facebook className="mr-2 h-4 w-4" /> Facebook</a></li>
                <li><a href="#" className="hover:underline flex items-center"><Instagram className="mr-2 h-4 w-4" /> Instagram</a></li>
                <li><a href="#" className="hover:underline flex items-center"><Youtube className="mr-2 h-4 w-4" /> YouTube</a></li>
                <li><a href="#" className="hover:underline flex items-center"><Podcast className="mr-2 h-4 w-4" /> Podcast</a></li>
              </ul>
            </div>
            <div className="w-full md:w-2/4">
              <h3 className="text-lg font-semibold mb-2">Newsletter</h3>
              <p className="mb-4">Stay updated with our weekly newsletter</p>
              <form className="flex gap-2">
                <input
                  type="email"
                  placeholder="Your email"
                  className="flex-grow px-3 py-2 border rounded-md"
                  required
                />
                <Button type="submit">Subscribe</Button>
              </form>
            </div>
          </div>
          <div className="mt-8 text-center">
            <p>&copy; {new Date().getFullYear()} Grace Community Church. All rights reserved.</p>
          </div>
        </div>
      </footer> */}
    </div>
  );
}
