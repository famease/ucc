import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import {
  Table,
  TableBody,
  TableCell,
  TableHead,
  TableHeader,
  TableRow,
} from "@/components/ui/table";

export default function ChurchBankingDetails() {
  return (
    <Card className="mt-8">
      <CardHeader>
        <CardTitle>Church Banking Details</CardTitle>
      </CardHeader>
      <CardContent>
        <Table>
          <TableHeader>
            <TableRow>
              <TableHead>Detail</TableHead>
              <TableHead>Value</TableHead>
            </TableRow>
          </TableHeader>
          <TableBody>
            <TableRow>
              <TableCell className="font-medium">Bank Name</TableCell>
              <TableCell>Nedbank</TableCell>
            </TableRow>
            <TableRow>
              <TableCell className="font-medium">Account Name</TableCell>
              <TableCell>Our Church</TableCell>
            </TableRow>
            <TableRow>
              <TableCell className="font-medium">Account Number</TableCell>
              <TableCell>1234567890</TableCell>
            </TableRow>
            <TableRow>
              <TableCell className="font-medium">Branch Code</TableCell>
              <TableCell>198765</TableCell>
            </TableRow>
            <TableRow>
              <TableCell className="font-medium">Account Type</TableCell>
              <TableCell>Current Account</TableCell>
            </TableRow>
            <TableRow>
              <TableCell className="font-medium">Reference</TableCell>
              <TableCell>
                Your Name + Purpose (e.g., &#34;John Doe Tithe&#34;)
              </TableCell>
            </TableRow>
          </TableBody>
        </Table>
        <p className="mt-4 text-sm text-muted-foreground">
          For international transfers, please use the following SWIFT code:
          NEDSZAJJ
        </p>
      </CardContent>
    </Card>
  );
}
