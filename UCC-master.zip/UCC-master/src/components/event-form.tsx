// "use client";

// import { useState } from "react";
// import { Button } from "@/components/ui/button";
// import { Input } from "@/components/ui/input";
// import { Label } from "@/components/ui/label";
// import { Textarea } from "@/components/ui/textarea";
// import {
//   Select,
//   SelectContent,
//   SelectItem,
//   SelectTrigger,
//   SelectValue,
// } from "@/components/ui/select";
// import { supabase } from "@/lib/supabaseClient";
// import { useUser } from "@clerk/nextjs";

// export function EventForm() {
//   const { user } = useUser(); // Clerk hook to get the authenticated user

//   const [formData, setFormData] = useState<{
//     title: string;
//     poster: File | null;
//     date: string;
//     startTime: string;
//     endTime: string;
//     description: string;
//     ministry: string;
//     setReminder: boolean;
//     location: string;
//   }>({
//     title: "",
//     poster: null,
//     date: "",
//     startTime: "",
//     endTime: "",
//     description: "",
//     ministry: "",
//     setReminder: false,
//     location: "",
//   });

//   const handleInputChange = (
//     e: React.ChangeEvent<HTMLInputElement | HTMLTextAreaElement>
//   ) => {
//     const { name, value, type, checked } = e.target;
//     setFormData((prev) => ({
//       ...prev,
//       [name]: type === "checkbox" ? checked : value,
//     }));
//   };

//   const handleFileChange = (e: React.ChangeEvent<HTMLInputElement>) => {
//     if (e.target.files && e.target.files.length > 0) {
//       setFormData((prev) => ({
//         ...prev,
//         poster: e.target.files[0],
//       }));
//     }
//   };

//   const handleSubmit = async (e: React.FormEvent) => {
//     e.preventDefault();

//     if (!user) {
//       console.error("User not authenticated");
//       return;
//     }

//     try {
//       const { data, error } = await supabase.from("events").insert({
//         title: formData.title,
//         poster_url: formData.poster
//           ? await uploadPoster(formData.poster)
//           : null,
//         date: formData.date,
//         start_time: formData.startTime,
//         end_time: formData.endTime,
//         description: formData.description,
//         ministry: formData.ministry,
//         set_reminder: formData.setReminder,
//         location: formData.location,
//         user_id: user.id, // Use Clerk's user ID
//       });

//       if (error) throw error;
//       console.log("Event created successfully:", data);
//     } catch (error: any) {
//       console.error("Error creating event:", error.message);
//     }
//   };

//   const uploadPoster = async (file: File) => {
//     const fileExt = file.name.split(".").pop();
//     const fileName = `${Math.random()}.${fileExt}`;
//     const { error: uploadError } = await supabase.storage
//       .from("event")
//       .upload(fileName, file);

//     if (uploadError) {
//       throw uploadError;
//     }

//     const { data, error: urlError } = supabase.storage
//       .from("event-posters")
//       .getPublicUrl(fileName);

//     if (urlError) {
//       throw urlError;
//     }

//     return data.publicURL;
//   };

//   return (
//     <form
//       onSubmit={handleSubmit}
//       className="space-y-6 max-w-lg mx-auto p-4 sm:p-6 md:p-8 bg-white rounded-lg shadow-md"
//     >
//       <div className="space-y-2">
//         <Label htmlFor="title">Event Title</Label>
//         <Input
//           id="title"
//           name="title"
//           value={formData.title}
//           onChange={handleInputChange}
//           required
//         />
//       </div>

//       <div className="space-y-2">
//         <Label htmlFor="poster">Event Poster</Label>
//         <Input
//           id="poster"
//           name="poster"
//           type="file"
//           onChange={handleFileChange}
//           accept="image/*"
//         />
//       </div>

//       <div className="space-y-2">
//         <Label htmlFor="date">Event Date</Label>
//         <Input
//           id="date"
//           name="date"
//           type="date"
//           value={formData.date}
//           onChange={handleInputChange}
//           required
//         />
//       </div>

//       <div className="flex flex-col sm:flex-row sm:space-x-4 space-y-4 sm:space-y-0">
//         <div className="flex-1 space-y-2">
//           <Label htmlFor="startTime">Start Time</Label>
//           <Input
//             id="startTime"
//             name="startTime"
//             type="time"
//             value={formData.startTime}
//             onChange={handleInputChange}
//             required
//           />
//         </div>
//         <div className="flex-1 space-y-2">
//           <Label htmlFor="endTime">End Time</Label>
//           <Input
//             id="endTime"
//             name="endTime"
//             type="time"
//             value={formData.endTime}
//             onChange={handleInputChange}
//             required
//           />
//         </div>
//       </div>

//       <div className="space-y-2">
//         <Label htmlFor="location">Location</Label>
//         <Input
//           id="location"
//           name="location"
//           value={formData.location}
//           onChange={handleInputChange}
//           required
//         />
//       </div>

//       <div className="space-y-2">
//         <Label htmlFor="description">Description</Label>
//         <Textarea
//           id="description"
//           name="description"
//           value={formData.description}
//           onChange={handleInputChange}
//           required
//         />
//       </div>

//       <div className="space-y-2">
//         <Label htmlFor="ministry">Ministry</Label>
//         <Select
//           name="ministry"
//           onValueChange={(value) =>
//             handleInputChange({ target: { name: "ministry", value } } as any)
//           }
//         >
//           <SelectTrigger>
//             <SelectValue placeholder="Select a ministry" />
//           </SelectTrigger>
//           <SelectContent>
//             <SelectItem value="youth">Youth Ministry</SelectItem>
//             <SelectItem value="worship">Worship Ministry</SelectItem>
//             <SelectItem value="outreach">Outreach Ministry</SelectItem>
//           </SelectContent>
//         </Select>
//       </div>

//       <div className="flex items-center space-x-2">
//         <Input
//           id="setReminder"
//           name="setReminder"
//           type="checkbox"
//           checked={formData.setReminder}
//           onChange={handleInputChange}
//           className="w-4 h-4"
//         />
//         <Label htmlFor="setReminder">Set Reminder</Label>
//       </div>

//       <Button type="submit" className="w-full" onClick={handleSubmit}>
//         Submit Event
//       </Button>
//     </form>
//   );
// }
