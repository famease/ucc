'use client'

import { useState } from 'react'
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card'
import { Input } from '@/components/ui/input'
import { Label } from '@/components/ui/label'
import { Button } from '@/components/ui/button'
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select'

export default function ChurchOfferingForm() {
  const [amount, setAmount] = useState('')
  const [accountHolder, setAccountHolder] = useState('')
  const [accountNumber, setAccountNumber] = useState('')
  const [accountType, setAccountType] = useState('')

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault()
    // Handle form submission (e.g., process payment through Nedbank)
    console.log('Church offering submitted:', { amount, accountHolder, accountNumber, accountType })
  }

  return (
    <Card>
      <CardHeader>
        <CardTitle>Church Offering</CardTitle>
        <CardDescription>Support our church&apos;s daily operations and ministries</CardDescription>
      </CardHeader>
      <CardContent>
        <form onSubmit={handleSubmit} className="space-y-4">
          <div className="space-y-2">
            <Label htmlFor="offering-amount">Offering Amount (R)</Label>
            <Input
              id="offering-amount"
              type="number"
              placeholder="Enter amount"
              value={amount}
              onChange={(e) => setAmount(e.target.value)}
              required
            />
          </div>
          <div className="space-y-2">
            <Label htmlFor="offering-account-holder">Account Holder Name</Label>
            <Input
              id="offering-account-holder"
              type="text"
              placeholder="Enter account holder name"
              value={accountHolder}
              onChange={(e) => setAccountHolder(e.target.value)}
              required
            />
          </div>
          <div className="space-y-2">
            <Label htmlFor="offering-account-number">Account Number</Label>
            <Input
              id="offering-account-number"
              type="text"
              placeholder="Enter account number"
              value={accountNumber}
              onChange={(e) => setAccountNumber(e.target.value)}
              required
            />
          </div>
          <div className="space-y-2">
            <Label htmlFor="offering-account-type">Account Type</Label>
            <Select value={accountType} onValueChange={setAccountType} required>
              <SelectTrigger id="offering-account-type">
                <SelectValue placeholder="Select account type" />
              </SelectTrigger>
              <SelectContent>
                <SelectItem value="current">Current Account</SelectItem>
                <SelectItem value="savings">Savings Account</SelectItem>
                <SelectItem value="credit">Credit Card</SelectItem>
              </SelectContent>
            </Select>
          </div>
          <Button type="submit" className="w-full">Give Offering</Button>
        </form>
      </CardContent>
    </Card>
  )
}

