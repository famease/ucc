import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card'
import { Table, TableBody, TableCell, TableRow } from '@/components/ui/table'
import { Button } from '@/components/ui/button'
import Link from 'next/link'
import { CopyableText } from './copyable-text'

export default function MissionsBankInfo() {
  return (
    <Card>
      <CardHeader>
        <CardTitle className="text-2xl">Support UCC Missions</CardTitle>
      </CardHeader>
      <CardContent>
        <h3 className="text-xl font-semibold mb-2">Upper Room Christian Centre</h3>
        <p className="mb-4">Your donation helps us feed hungry children in our community.</p>
        
        <h4 className="text-lg font-semibold mb-2">Banking Details</h4>
        <Table>
          <TableBody>
            <TableRow>
              <TableCell className="font-medium">Bank</TableCell>
              <TableCell><CopyableText text='Nedbank'/></TableCell>
            </TableRow>
            <TableRow>
              <TableCell className="font-medium">Account No</TableCell>
              <TableCell><CopyableText text='1156563100'/></TableCell>
            </TableRow>
            <TableRow>
              <TableCell className="font-medium">Branch Code</TableCell>
              <TableCell><CopyableText text='198 765'/></TableCell>
            </TableRow>
            <TableRow>
              <TableCell className="font-medium">Reference</TableCell>
              <TableCell>UCC Missions/Your Name</TableCell>
            </TableRow>
          </TableBody>
        </Table>
        
        <div className="mt-6 mb-6">
          <Button asChild>
            <Link href="/ministries/missions">Learn More About UCC Missions</Link>
          </Button>
        </div>
        
        <blockquote className="mt-6 border-l-2 pl-6 italic">
          &#34;Whoever is kind to the poor lends to the Lord, and he will reward them for what they have done.&#34;
          <footer className="text-right">— Proverbs 19:17</footer>
        </blockquote>
      </CardContent>
    </Card>
  )
}

