// 'use client'

// import { useState } from 'react'
// import Image from 'next/image'
// import Link from 'next/link'
// import { CalendarIcon, ChevronLeftIcon, ChevronRightIcon, TagIcon } from 'lucide-react'
// import { Button } from '@/components/ui/button'
// import { Card, CardContent, CardFooter, CardHeader, CardTitle } from '@/components/ui/card'
// import { Badge } from '@/components/ui/badge'

// // This would typically come from a CMS or API
// const allBlogPosts = [
//   {
//     id: 1,
//     title: "Sunday Sermon: The Power of Faith",
//     date: "2023-06-18",
//     content: "In our fast-paced world, it's easy to lose sight of what truly matters. Faith, however, remains a cornerstone of our spiritual journey. This Sunday, Pastor John will delve into the transformative power of faith and how it can guide us through life's challenges. We'll explore biblical examples of unwavering faith and discuss practical ways to strengthen our own faith in daily life.",
//     type: "Message",
//     tags: ["Sermon", "Faith", "Spiritual Growth"],
//     image: "/placeholder.svg?height=400&width=600"
//   },
//   {
//     id: 2,
//     title: "Youth Group Summer Retreat",
//     date: "2023-07-05",
//     content: "Exciting news for our youth! We're organizing a summer retreat filled with fun activities, spiritual growth, and unforgettable memories. From outdoor adventures to heartfelt worship sessions, this retreat is designed to help our young members deepen their faith and build lasting friendships. Don't miss out on this amazing opportunity to connect with God and fellow believers in a beautiful natural setting.",
//     type: "Event",
//     tags: ["Youth", "Retreat", "Community"],
//     image: "/placeholder.svg?height=300&width=400"
//   },
//   {
//     id: 3,
//     title: "Bible Study: Book of Romans",
//     date: "2023-06-25",
//     content: "Join us for an in-depth study of the Book of Romans, one of the most influential books in the New Testament. Over the next few weeks, we'll explore Paul's profound teachings on faith, grace, and salvation. This study will challenge and inspire you, providing fresh insights into the core of Christian doctrine. Whether you're new to Bible study or a seasoned participant, all are welcome to join this enlightening journey through Romans.",
//     type: "Message",
//     tags: ["Bible Study", "Romans", "Doctrine"],
//     image: "/placeholder.svg?height=300&width=400"
//   },
//   {
//     id: 4,
//     title: "Community Outreach: Food Drive",
//     date: "2023-07-10",
//     content: "As part of our ongoing commitment to serve our community, we're organizing a food drive to support local families in need. This is a wonderful opportunity to put our faith into action and make a tangible difference in people's lives. We're collecting non-perishable food items, hygiene products, and household essentials. Let's come together as a church family to show God's love through our generosity and compassion.",
//     type: "Event",
//     tags: ["Outreach", "Community Service", "Charity"],
//     image: "/placeholder.svg?height=300&width=400"
//   },
//   {
//     id: 5,
//     title: "Worship Night: Praise Under the Stars",
//     date: "2023-07-15",
//     content: "Join us for a special evening of worship as we gather under the stars to lift our voices in praise. This outdoor event will feature our worship team leading us in both contemporary and traditional hymns. It's a perfect opportunity to invite friends and neighbors to experience the joy of communal worship in a relaxed, natural setting. Bring your lawn chairs or blankets and prepare your hearts for a night of spiritual renewal.",
//     type: "Event",
//     tags: ["Worship", "Music", "Community"],
//     image: "/placeholder.svg?height=300&width=400"
//   },
//   {
//     id: 6,
//     title: "Marriage Enrichment Workshop",
//     date: "2023-07-22",
//     content: "Invest in your marriage at our upcoming Marriage Enrichment Workshop. Led by experienced counselors, this workshop will provide practical tools and biblical wisdom to strengthen your relationship. Topics will include effective communication, conflict resolution, and nurturing intimacy. Whether you're newlyweds or have been married for decades, this workshop offers valuable insights for every couple seeking to deepen their bond.",
//     type: "Event",
//     tags: ["Marriage", "Workshop", "Relationships"],
//     image: "/placeholder.svg?height=300&width=400"
//   }
// ]

// function truncateWords(text: string, limit: number) {
//   const words = text.split(' ')
//   if (words.length > limit) {
//     return words.slice(0, limit).join(' ') + '...'
//   }
//   return text
// }

// function BlogPostCard({ post, isFeatured = false }) {
//   const previewContent = truncateWords(post.content, isFeatured ? 50 : 30)

//   return (
//     <Card className={`h-full flex flex-col ${isFeatured ? 'md:flex-row' : ''}`}>
//       <div className={`relative ${isFeatured ? 'h-64 md:w-1/2 md:h-auto' : 'h-48'}`}>
//         <Image
//           src={post.image}
//           alt={post.title}
//           layout="fill"
//           objectFit="cover"
//           className={`rounded-t-lg ${isFeatured ? 'md:rounded-l-lg md:rounded-t-none' : ''}`}
//         />
//       </div>
//       <div className={`flex flex-col ${isFeatured ? 'md:w-1/2' : ''}`}>
//         <CardHeader>
//           <CardTitle className={isFeatured ? "text-2xl mb-2" : "text-xl mb-2"}>{post.title}</CardTitle>
//           <div className="flex items-center text-sm text-muted-foreground mb-2">
//             <CalendarIcon className="mr-2 h-4 w-4" />
//             <time dateTime={post.date}>
//               {new Date(post.date).toLocaleDateString('en-US', {
//                 year: 'numeric',
//                 month: 'long',
//                 day: 'numeric'
//               })}
//             </time>
//           </div>
//           <div className="flex flex-wrap gap-2">
//             {post.tags.map((tag, index) => (
//               <Badge key={index} variant="secondary">
//                 <TagIcon className="mr-1 h-3 w-3" />
//                 {tag}
//               </Badge>
//             ))}
//           </div>
//         </CardHeader>
//         <CardContent>
//           <p className="text-sm text-gray-600 mb-4">{previewContent}</p>
//           <span className="text-sm font-medium">
//             {post.type === "Message" ? "Message" : "Event"}
//           </span>
//         </CardContent>
//         <CardFooter className="mt-auto">
//           <Link href={`/blog/${post.id}`} passHref>
//             <Button variant="outline" size="sm">
//               Read More
//               <span className="sr-only">about {post.title}</span>
//             </Button>
//           </Link>
//         </CardFooter>
//       </div>
//     </Card>
//   )
// }

// export function BlogPage() {
//   const [currentPage, setCurrentPage] = useState(1)
//   const postsPerPage = 5
//   const [featuredPost, ...otherPosts] = allBlogPosts
//   const indexOfLastPost = currentPage * postsPerPage
//   const indexOfFirstPost = indexOfLastPost - postsPerPage
//   const currentPosts = otherPosts.slice(indexOfFirstPost, indexOfLastPost)
//   const totalPages = Math.ceil(otherPosts.length / postsPerPage)

//   return (
//     <div className="min-h-screen bg-gray-50 py-12">
//       <div className="container mx-auto px-4">
//         <h1 className="text-4xl font-bold text-center mb-12">Our Church Blog</h1>

//         <div className="mb-12">
//           <BlogPostCard post={featuredPost} isFeatured={true} />
//         </div>

//         <div className="grid gap-6 md:grid-cols-2 lg:grid-cols-3">
//           {currentPosts.map((post) => (
//             <BlogPostCard key={post.id} post={post} />
//           ))}
//         </div>

//         {totalPages > 1 && (
//           <div className="mt-12 flex justify-center items-center space-x-4">
//             <Button
//               variant="outline"
//               onClick={() => setCurrentPage(prev => Math.max(prev - 1, 1))}
//               disabled={currentPage === 1}
//             >
//               <ChevronLeftIcon className="h-4 w-4 mr-2" />
//               Previous
//             </Button>
//             <span className="text-sm text-gray-600">
//               Page {currentPage} of {totalPages}
//             </span>
//             <Button
//               variant="outline"
//               onClick={() => setCurrentPage(prev => Math.min(prev + 1, totalPages))}
//               disabled={currentPage === totalPages}
//             >
//               Next
//               <ChevronRightIcon className="h-4 w-4 ml-2" />
//             </Button>
//           </div>
//         )}
//       </div>
//     </div>
//   )
// }

import React from "react";

function blogpage() {
  return <div>blog-page</div>;
}

export default blogpage;
