"use client";

import { Card, CardContent } from "@/components/ui/card";
import {
  RiUserLine,
  RiGlobalLine,
  RiHeartLine,
  RiGroupLine,
  RiEarthLine,
  RiCrossLine,
  RiCrossFill,
} from "@remixicon/react";
export function MissionSection() {
  return (
    <section className="py-16 bg-gray-50">
      <div className="container mx-auto px-4">
        <h2 className="text-3xl md:text-4xl font-bold text-center mb-8">
          Our Mission
        </h2>
        <p className="text-xl text-center text-gray-600 mb-12 max-w-3xl mx-auto">
          At Our Church, we are committed to spreading God&apos;s love,
          building a strong community, and making a positive impact in the world
          around us.
        </p>
        <div className="grid grid-cols-1 md:grid-cols-3 gap-8">
          <MissionCard
            icon={<RiCrossFill className="h-12 w-12 text-primary" />}
            title="Spread God's Love"
            description="We aim to share the message of God's unconditional love and grace with everyone we encounter."
          />
          <MissionCard
            icon={<RiGroupLine className="h-12 w-12 text-primary" />}
            title="Build Community"
            description="We foster a welcoming environment where people can connect, grow, and support one another in their faith journey."
          />
          <MissionCard
            icon={<RiEarthLine className="h-12 w-12 text-primary" />}
            title="Serve Jesus"
            description="We are dedicated to making a positive impact in our local community and beyond through outreach and service."
          />
        </div>
      </div>
    </section>
  );
}

function MissionCard({
  icon,
  title,
  description,
}: {
  icon: React.ReactNode;
  title: string;
  description: string;
}) {
  return (
    <Card className="text-center">
      <CardContent className="pt-6">
        <div className="mb-4 inline-flex items-center justify-center w-16 h-16 rounded-full bg-primary/10">
          {icon}
        </div>
        <h3 className="text-xl font-semibold mb-2">{title}</h3>
        <p className="text-gray-600">{description}</p>
      </CardContent>
    </Card>
  );
}
