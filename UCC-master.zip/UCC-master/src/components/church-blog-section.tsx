"use client";

import Image from "next/image";
import Link from "next/link";
import { CalendarIcon, ChevronRightIcon } from "lucide-react";
import { Button } from "@/components/ui/button";
import {
  Card,
  CardContent,
  CardFooter,
  CardHeader,
  CardTitle,
} from "@/components/ui/card";

interface BlogPost {
  id: number;
  title: string;
  date: string;
  content: string;
  type: string;
  image?: string;
}
// This would typically come from a CMS or API
const blogPosts = [
  {
    id: 1,
    title: "Sunday Sermon: The Power of Faith",
    date: "2023-06-18",
    content:
      "In our fast-paced world, it's easy to lose sight of what truly matters. Faith, however, remains a cornerstone of our spiritual journey. This Sunday, Pastor John will delve into the transformative power of faith and how it can guide us through life's challenges. We'll explore biblical examples of unwavering faith and discuss practical ways to strengthen our own faith in daily life.",
    type: "Message",
    image: "/placeholder.svg?height=400&width=600",
  },
  {
    id: 2,
    title: "Youth Group Summer Retreat",
    date: "2023-07-05",
    content:
      "Exciting news for our youth! We're organizing a summer retreat filled with fun activities, spiritual growth, and unforgettable memories. From outdoor adventures to heartfelt worship sessions, this retreat is designed to help our young members deepen their faith and build lasting friendships. Don't miss out on this amazing opportunity to connect with God and fellow believers in a beautiful natural setting.",
    type: "Event",
  },
  {
    id: 3,
    title: "Bible Study: Book of Romans",
    date: "2023-06-25",
    content:
      "Join us for an in-depth study of the Book of Romans, one of the most influential books in the New Testament. Over the next few weeks, we'll explore Paul's profound teachings on faith, grace, and salvation. This study will challenge and inspire you, providing fresh insights into the core of Christian doctrine. Whether you're new to Bible study or a seasoned participant, all are welcome to join this enlightening journey through Romans.",
    type: "Message",
  },
  {
    id: 4,
    title: "Community Outreach: Food Drive",
    date: "2023-07-10",
    content:
      "As part of our ongoing commitment to serve our community, we're organizing a food drive to support local families in need. This is a wonderful opportunity to put our faith into action and make a tangible difference in people's lives. We're collecting non-perishable food items, hygiene products, and household essentials. Let's come together as a church family to show God's love through our generosity and compassion.",
    type: "Event",
  },
];

function truncateWords(text: string, limit: number) {
  const words = text.split(" ");
  if (words.length > limit) {
    return words.slice(0, limit).join(" ") + "...";
  }
  return text;
}

function BlogPostCard({
  post,
  isMain = false,
}: {
  post: BlogPost;
  isMain?: boolean;
}) {
  const previewContent = truncateWords(post.content, 50);

  return (
    <Card className={`h-full flex flex-col ${isMain ? "md:flex-row" : ""}`}>
      {isMain && (
        <div className="md:w-1/2 relative h-48 md:h-auto">
          <Image
            src={post.image ?? "/default-image.jpg"}
            alt={post.title}
            layout="fill"
            objectFit="cover"
            className="rounded-t-lg md:rounded-l-lg md:rounded-t-none"
          />
        </div>
      )}
      <div className={`flex flex-col ${isMain ? "md:w-1/2" : ""}`}>
        <CardHeader>
          <CardTitle className={isMain ? "text-2xl" : "text-lg"}>
            {post.title}
          </CardTitle>
          <div className="flex items-center text-sm text-muted-foreground">
            <CalendarIcon className="mr-2 h-4 w-4" />
            <time dateTime={post.date}>
              {new Date(post.date).toLocaleDateString("en-US", {
                year: "numeric",
                month: "long",
                day: "numeric",
              })}
            </time>
          </div>
        </CardHeader>
        <CardContent>
          <p className="mb-4 text-sm text-gray-600">{previewContent}</p>
          <span className="text-sm font-medium">
            {post.type === "Message" ? "Message" : "Event"}
          </span>
        </CardContent>
        <CardFooter className="mt-auto">
          <Button variant="outline" size="sm">
            Read More
            <span className="sr-only">about {post.title}</span>
          </Button>
        </CardFooter>
      </div>
    </Card>
  );
}

export function ChurchBlogSection() {
  const [mainPost, ...otherPosts] = blogPosts;

  return (
    <section className="py-12 bg-gray-50">
      <div className="container mx-auto px-4">
        <h2 className="text-3xl font-bold text-center mb-8">
          Latest from Our Church
        </h2>
        <div className="grid gap-6 md:grid-cols-2 lg:grid-cols-3">
          <div className="md:col-span-2 lg:col-span-2">
            <BlogPostCard post={mainPost} isMain={true} />
          </div>
          {otherPosts.map((post) => (
            <BlogPostCard key={post.id} post={post} />
          ))}
        </div>
        <div className="text-center mt-8">
          <Link href="/blog" passHref>
            <Button variant="link" className="text-primary">
              Visit Our Blog
              <ChevronRightIcon className="ml-2 h-4 w-4" />
            </Button>
          </Link>
        </div>
      </div>
    </section>
  );
}
