"use client";

import Link from "next/link";
// import { CreatorBannerComponent } from "./DevTag";
import {
  RiFacebookFill,
  RiInstagramFill,
  RiMailFill,
  RiMap2Fill,
  RiPhoneFill,
} from "@remixicon/react";

export function Footer() {
  return (
    <footer className="bg-gray-900 text-gray-300">
      <div className="container mx-auto px-4 py-12">
        <div className="grid gap-8 md:grid-cols-2 lg:grid-cols-4">
          {/* Contact Information */}
          <div>
            <h2 className="text-2xl font-bold mb-4 text-white">Contact Us</h2>
            <ul className="space-y-2">
              <li className="flex items-center">
                <RiMap2Fill className="h-5 w-5 mr-2" />
                2-4 Reeders St, Haddon, JHB South 2190
              </li>
              <li className="flex items-center">
                <RiPhoneFill className="h-5 w-5 mr-2" />
                011 683 0075
              </li>
              <li className="flex items-center">
                <RiMailFill className="h-5 w-5 mr-2" />
                uccjhbsouth@gmail.com
              </li>
            </ul>
          </div>

          {/* Quick Links / Sitemap */}
          <div>
            <h2 className="text-2xl font-bold mb-4 text-white">Quick Links</h2>
            <ul className="space-y-2">
              <li>
                <Link href="/" className="hover:text-white transition-colors">
                  Home
                </Link>
              </li>
              <li>
                <Link
                  href="/about"
                  className="hover:text-white transition-colors"
                >
                  About Us
                </Link>
              </li>
              <li>
                <Link
                  href="/missions"
                  className="hover:text-white transition-colors"
                >
                  UCC Missions
                </Link>
              </li>
              <li>
                <Link
                  href="/tithes"
                  className="hover:text-white transition-colors"
                >
                  Tithes & Offerings
                </Link>
              </li>
              <li>
                <Link
                  href="/contact"
                  className="hover:text-white transition-colors"
                >
                  Contact
                </Link>
              </li>
              <li>
                <Link
                  href="/ministries"
                  className="hover:text-white transition-colors"
                >
                  Ministries
                </Link>
              </li>
            </ul>
          </div>

          {/* Social Media */}
          <div>
            <h2 className="text-2xl font-bold mb-4 text-white">
              Connect With Us
            </h2>
            <div className="flex space-x-4">
              <a
                href="https://www.facebook.com/uc.christian.9/?paipv=0&eav=AfZxZ0a5JRGceQgMRfAebuD9PzP2gyoYcQxx5r0eFE1P8yX9hePNz8oum4RWxrPLhBY&_rdr"
                target="_blank"
                rel="noopener noreferrer"
                className="hover:text-white transition-colors"
              >
                <RiFacebookFill className="h-6 w-6" />
                <span className="sr-only">Facebook</span>
              </a>

              <a
                href="https://www.instagram.com/ucc_missions/"
                target="_blank"
                rel="noopener noreferrer"
                className="hover:text-white transition-colors"
              >
                <RiInstagramFill className="h-6 w-6" />
                <span className="sr-only">Instagram</span>
              </a>
              {/* <a
                href="https://youtube.com"
                target="_blank"
                rel="noopener noreferrer"
                className="hover:text-white transition-colors"
              >
                <RiYoutubeFill className="h-6 w-6" />
                <span className="sr-only">YouTube</span>
              </a> */}
            </div>
          </div>

          {/* Newsletter Signup (CTA)
          <div>
            <h2 className="text-2xl font-bold mb-4 text-white">
              Stay Connected
            </h2>
            <p className="mb-4">
              Sign up for our newsletter to receive updates and inspirational
              messages.
            </p>
            <form onSubmit={(e) => e.preventDefault()} className="space-y-2">
              <Input
                type="email"
                placeholder="Your email"
                className="bg-gray-800 border-gray-700 text-white placeholder-gray-400"
              />
              <Button type="submit" className="w-full">
                Subscribe
              </Button>
            </form>
        </div> */}
        </div>

        {/* Map Integration
        <div className="mt-12">
          <h2 className="text-2xl font-bold mb-4 text-white">Find Us</h2>
          <div className="aspect-video w-full max-w-2xl mx-auto">
            <iframe
              src="https://www.google.com/maps/embed?pb=!1m14!1m8!1m3!1d14312.65828598568!2d28.0314078!3d-26.2563217!3m2!1i1024!2i768!4f13.1!3m3!1m2!1s0x1e950f3aba26b309%3A0xcc0c81e944a5927e!2sUpper%20Room%20Christian%20Centre!5e0!3m2!1sen!2sza!4v1725973967085!5m2!1sen!2sza"
              width="600"
              height="450"
              // style={{ border: black }}
              allowFullScreen
              loading="lazy"
              referrerPolicy="no-referrer-when-downgrade"
            ></iframe>
          </div>
        </div> */}

        {/* Copyright */}
        <div className="mt-12 pt-8 border-t border-gray-800 text-center">
          <p>
            &copy; {new Date().getFullYear()} Upperroom Christian Center. All
            rights reserved.
          </p>
        </div>
      </div>
      {/* <CreatorBannerComponent /> */}
    </footer>
  );
}
