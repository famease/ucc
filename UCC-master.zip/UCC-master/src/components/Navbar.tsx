"use client";

import { useState } from "react";
import Link from "next/link";
import { Menu, X, ChevronDown, Phone, Mail } from "lucide-react";
import { Button } from "@/components/ui/button";
import {
  DropdownMenu,
  DropdownMenuContent,
  DropdownMenuItem,
  DropdownMenuTrigger,
} from "@/components/ui/dropdown-menu";
import Image from "next/image";

const navigation = [
  { name: "Home", href: "/" },
  { name: "About Us", href: "/about" },
  { name: "Tithes & Offering", href: "/tithes" },
  // { name: "Events", href: "/events" },
  { name: "Contact Us", href: "/contact" },
];

export function Navbar() {
  const [mobileMenuOpen, setMobileMenuOpen] = useState(false);

  return (
    <header className="bg-white shadow-md">
      {/* Top banner */}
      <div className="hidden bg-primary text-primary-foreground py-2 px-4 text-sm md:flex justify-between items-center">
        <div className="flex items-center space-x-4">
          <span className="flex items-center">
            <Phone className="h-4 w-4 mr-1" />
            011 683 0075
          </span>
          <span className="flex items-center">
            <Mail className="h-4 w-4 mr-1" />
            uccjhbsouth@gmail.com
          </span>
        </div>
        <Link href="/tithes" className="inline-flex items-center justify-center rounded-md bg-secondary px-4 py-2 text-sm text-secondary-foreground">
          Show Support
        </Link>
      </div>

      {/* Main navbar */}
      <nav
        className="mx-auto flex max-w-7xl items-center justify-between p-6 md:px-8 "
        aria-label="Global"
      >
        <div className="flex md:flex-1">
          <Link href="/" className="-m-1.5 p-1.5">
            <span className="sr-only">Uperroom Christian Center</span>
            <Image
              className="h-16 w-auto"
              src="/logo-nobg.png"
              alt="Church Logo"
              width={100}
              height={40}
            />
          </Link>
        </div>
        <div className="flex md:hidden">
          <button
            type="button"
            className="-m-2.5 inline-flex items-center justify-center rounded-md p-2.5 text-gray-700"
            onClick={() => setMobileMenuOpen(true)}
          >
            <span className="sr-only">Open main menu</span>
            <Menu className="h-6 w-6" aria-hidden="true" />
          </button>
        </div>
        <div className="hidden md:flex md:gap-x-8">
          {navigation.map((item) => (
            <Link
              key={item.name}
              href={item.href}
              className="text-sm font-semibold leading-6 text-gray-900 hover:text-primary"
            >
              {item.name}
            </Link>
          ))}
          <DropdownMenu>
            <DropdownMenuTrigger asChild>
              <span className="text-sm font-semibold leading-6 text-gray-900 hover:text-primary cursor-pointer flex items-center">
                Ministries <ChevronDown className="ml-1 h-4 w-4" />
              </span>
            </DropdownMenuTrigger>
            <DropdownMenuContent align="end">
              <DropdownMenuItem>
                <Link href="/ministries/youth" className="w-full">
                  One2Nine Generation
                </Link>
              </DropdownMenuItem>
              <DropdownMenuItem>
                <Link href="/ministries/missions" className="w-full">
                  UCC Missions
                </Link>
              </DropdownMenuItem>
              <DropdownMenuItem>
                <Link href="/ministries/wov" className="w-full">
                  Women Of Valor
                </Link>
              </DropdownMenuItem>
              <DropdownMenuItem>
                <Link href="/ministries/brothers" className="w-full">
                  Brothers Ministry
                </Link>
              </DropdownMenuItem>
              <DropdownMenuItem>
                <Link href="/ministries/cr" className="w-full">
                  Celebrate Recovery
                </Link>
              </DropdownMenuItem>
              <DropdownMenuItem>
                <Link href="/ministries/sunday-school" className="w-full">
                  Sunday School
                </Link>
              </DropdownMenuItem>
            </DropdownMenuContent>
          </DropdownMenu>
        </div>
      </nav>

      {/* Mobile menu */}
      {mobileMenuOpen && (
        <div
          className="md:hidden bg-opacity-25"
          role="dialog"
          aria-modal="true"
        >
          <div className="fixed inset-0 z-50"></div>
          <div className="fixed inset-y-0 right-0 z-50 w-full overflow-y-auto bg-white px-6 py-6 sm:max-w-sm sm:ring-1 sm:ring-gray-900/10">
            <div className="flex items-center justify-between">
              <Link href="/" className="-m-1.5 p-1.5">
                <span className="sr-only">Your Church</span>
                <Image
                  className="h-16 w-auto"
                  src="/logo-nobg.png"
                  alt="Church Logo"
                  width={100}
                  height={40}
                />
              </Link>
              <button
                type="button"
                className="-m-2.5 rounded-md p-2.5 text-gray-700"
                onClick={() => setMobileMenuOpen(false)}
              >
                <span className="sr-only">Close menu</span>
                <X className="h-6 w-6" aria-hidden="true" />
              </button>
            </div>
            <div className="mt-6 flow-root">
              <div className="-my-6 divide-y divide-gray-500/10">
                <div className="space-y-2 py-6">
                  {navigation.map((item) => (
                    <Link
                      key={item.name}
                      href={item.href}
                      className="-mx-3 block rounded-lg px-3 py-2 text-base font-semibold leading-7 text-gray-900 hover:bg-gray-50"
                      onClick={() => setMobileMenuOpen(false)}
                    >
                      {item.name}
                    </Link>
                  ))}
                  <DropdownMenu>
                    <DropdownMenuTrigger asChild>
                      <span className="-mx-3 block rounded-lg px-3 py-2 text-base font-semibold leading-7 text-gray-900 hover:bg-gray-50 cursor-pointer">
                        Ministries{" "}
                        <ChevronDown className="ml-1 h-4 w-4 inline" />
                      </span>
                    </DropdownMenuTrigger>
                    <DropdownMenuContent>
                      <DropdownMenuItem>
                        <Link
                          href="/ministries/youth"
                          className="w-full"
                          onClick={() => setMobileMenuOpen(false)}
                        >
                          One2Nine Generation
                        </Link>
                      </DropdownMenuItem>
                      <DropdownMenuItem>
                        <Link
                          href="/ministries/missions"
                          className="w-full"
                          onClick={() => setMobileMenuOpen(false)}
                        >
                          UCC Missions
                        </Link>
                      </DropdownMenuItem>
                      <DropdownMenuItem>
                        <Link
                          href="/ministries/wov"
                          className="w-full"
                          onClick={() => setMobileMenuOpen(false)}
                        >
                          Women Of Valor
                        </Link>
                      </DropdownMenuItem>
                      <DropdownMenuItem>
                        <Link
                          href="/ministries/brothers"
                          className="w-full"
                          onClick={() => setMobileMenuOpen(false)}
                        >
                          Brothers Ministry
                        </Link>
                      </DropdownMenuItem>
                      <DropdownMenuItem>
                        <Link
                          href="/ministries/cr"
                          className="w-full"
                          onClick={() => setMobileMenuOpen(false)}
                        >
                          Celebrate Recovery
                        </Link>
                      </DropdownMenuItem>
                      <DropdownMenuItem>
                        <Link
                          href="/ministries/sunday-school"
                          className="w-full"
                          onClick={() => setMobileMenuOpen(false)}
                        >
                          Sunday School
                        </Link>
                      </DropdownMenuItem>
                    </DropdownMenuContent>
                  </DropdownMenu>
                </div>
                <div className="py-6">
                  <Button
                    variant={"outline"}
                    className="w-full "
                    onClick={() => setMobileMenuOpen(false)}
                    asChild
                  >
                    <Link href="/tithes">Show Support</Link>
                  </Button>
                </div>
              </div>
            </div>
          </div>
        </div>
      )}
    </header>
  );
}
