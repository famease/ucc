'use client'

import { useState } from 'react'
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card'
import { Input } from '@/components/ui/input'
import { Label } from '@/components/ui/label'
import { Button } from '@/components/ui/button'
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select'

export default function CharityDonationForm() {
  const [amount, setAmount] = useState('')
  const [accountHolder, setAccountHolder] = useState('')
  const [accountNumber, setAccountNumber] = useState('')
  const [accountType, setAccountType] = useState('')

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault()
    // Handle form submission (e.g., process payment through Nedbank)
    console.log('Charity donation submitted:', { amount, accountHolder, accountNumber, accountType })
  }

  return (
    <Card>
      <CardHeader>
        <CardTitle>Support Missions</CardTitle>
        <CardDescription>Support our community outreach programs</CardDescription>
      </CardHeader>
      <CardContent>
        <form onSubmit={handleSubmit} className="space-y-4">
          <div className="space-y-2">
            <Label htmlFor="charity-amount">Donation Amount (R)</Label>
            <Input
              id="charity-amount"
              type="number"
              placeholder="Enter amount"
              value={amount}
              onChange={(e) => setAmount(e.target.value)}
              required
            />
          </div>
          <div className="space-y-2">
            <Label htmlFor="charity-account-holder">Account Holder Name</Label>
            <Input
              id="charity-account-holder"
              type="text"
              placeholder="Enter account holder name"
              value={accountHolder}
              onChange={(e) => setAccountHolder(e.target.value)}
              required
            />
          </div>
          <div className="space-y-2">
            <Label htmlFor="charity-account-number">Account Number</Label>
            <Input
              id="charity-account-number"
              type="text"
              placeholder="Enter account number"
              value={accountNumber}
              onChange={(e) => setAccountNumber(e.target.value)}
              required
            />
          </div>
          <div className="space-y-2">
            <Label htmlFor="charity-account-type">Account Type</Label>
            <Select value={accountType} onValueChange={setAccountType} required>
              <SelectTrigger id="charity-account-type">
                <SelectValue placeholder="Select account type" />
              </SelectTrigger>
              <SelectContent>
                <SelectItem value="current">Current Account</SelectItem>
                <SelectItem value="savings">Savings Account</SelectItem>
                <SelectItem value="credit">Credit Card</SelectItem>
              </SelectContent>
            </Select>
          </div>
          <Button type="submit" className="w-full">Donate to Missions</Button>
        </form>
      </CardContent>
    </Card>
  )
}

