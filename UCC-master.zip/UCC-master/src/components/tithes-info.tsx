import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Table, TableBody, TableCell, TableRow } from "@/components/ui/table";
import { CopyableText } from "./copyable-text";
export default function TithesAndOfferingInfo() {
  return (
    <Card>
      <CardHeader>
        <CardTitle className="text-2xl">Tithes & Offering</CardTitle>
      </CardHeader>
      <CardContent>
        <h3 className="text-xl font-semibold mb-2">
          Upper Room Christian Centre
        </h3>
        <p className="mb-4">Your generosity supports our mission.</p>

        <h4 className="text-lg font-semibold mb-2">Banking Details</h4>
        <Table>
          <TableBody>
            <TableRow>
              <TableCell className="font-medium">Bank</TableCell>
              <TableCell>
                <CopyableText text="Nedbank" />
              </TableCell>
            </TableRow>
            <TableRow>
              <TableCell className="font-medium">Account No</TableCell>
              <TableCell>
                <CopyableText text="1034095285" />
              </TableCell>
            </TableRow>
            <TableRow>
              <TableCell className="font-medium">Branch Code</TableCell>
              <TableCell>
                <CopyableText text="198 765" />
              </TableCell>
            </TableRow>
          </TableBody>
        </Table>

        <blockquote className="mt-6 border-l-2 pl-6 italic">
          &#34;But remember the Lord your God, for it is he who gives you the
          ability to produce wealth.&#34;
          <footer className="text-right">— Deuteronomy 8:18</footer>
        </blockquote>
      </CardContent>
    </Card>
  );
}
