import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card'

export default function PhysicalDonations() {
  return (
    <Card className="mt-8">
      <CardHeader>
        <CardTitle>Donate Physical Items</CardTitle>
        <CardDescription>Your donations make a difference in our community</CardDescription>
      </CardHeader>
      <CardContent>
        <p className="mb-4">We welcome donations of physical items to support our various ministries and outreach programs. Here are some items we currently need:</p>
        <ul className="list-disc pl-6 space-y-2">
          <li>Non-perishable food items for our food bank</li>
          <li>Gently used clothing for our clothing drive</li>
          <li>School supplies for underprivileged children</li>
          <li>Hygiene products for our homeless outreach program</li>
        </ul>
        <p className="mt-4">Please bring your donations to the church during our operating hours. Thank you for your generosity!</p>
      </CardContent>
    </Card>
  )
}

