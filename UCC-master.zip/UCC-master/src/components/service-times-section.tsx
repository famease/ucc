"use client";

import { useState } from "react";
import { Clock, MapPin, Calendar, Bell } from "lucide-react";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { toast } from "@/components/ui/use-toast";

const services = [
  {
    day: "Sunday",
    startTime: "8:15 AM",
    endTime: "10:00 AM",
    name: "One2Nine Generation Service",
  },
  {
    day: "Sunday",
    startTime: "10:30 AM",
    endTime: "12:30 PM",
    name: "Sunday Service Service",
  },
  {
    day: "Tuesday",
    startTime: "7:00 PM",
    endTime: "8:00 PM",
    name: "Evening Prayer",
  },
  {
    day: "Friday",
    startTime: "6:30 PM",
    endTime: "20:00 PM",
    name: "Celebrate Recovery",
  },
];

export function ServiceTimesSection() {
  const [isReminderSet, setIsReminderSet] = useState(
    Array(services.length).fill(false)
  );

  const addToCalendar = (index: number) => {
    const service = services[index];
    const now = new Date();
    const daysOfWeek = [
      "Sunday",
      "Monday",
      "Tuesday",
      "Wednesday",
      "Thursday",
      "Friday",
      "Saturday",
    ];
    const targetDayIndex = daysOfWeek.indexOf(service.day);
    const daysUntilTarget = (targetDayIndex + 7 - now.getDay()) % 7;
    const targetDate = new Date(
      now.getFullYear(),
      now.getMonth(),
      now.getDate() + daysUntilTarget
    );

    const formatDate = (date: Date) => {
      return date.toISOString().replace(/[-:]/g, "").split(".")[0] + "Z";
    };

    const startDateTime = new Date(targetDate);
    const [startHours, startMinutes] = service.startTime
      .match(/(\d+):(\d+)/)!
      .slice(1);
    startDateTime.setHours(
      parseInt(startHours, 10) + (service.startTime.includes("PM") ? 12 : 0)
    );
    startDateTime.setMinutes(parseInt(startMinutes, 10));

    const endDateTime = new Date(targetDate);
    const [endHours, endMinutes] = service.endTime
      .match(/(\d+):(\d+)/)!
      .slice(1);
    endDateTime.setHours(
      parseInt(endHours, 10) + (service.endTime.includes("PM") ? 12 : 0)
    );
    endDateTime.setMinutes(parseInt(endMinutes, 10));

    const event = {
      title: service.name,
      description: `${service.name} at UCC`,
      location: "2-4 Reeders St, Haddon, Johannesburg South 2190",
      startTime: formatDate(startDateTime),
      endTime: formatDate(endDateTime),
    };

    // Create calendar event URL
    const googleCalendarUrl = `https://www.google.com/calendar/render?action=TEMPLATE&text=${encodeURIComponent(
      event.title
    )}&details=${encodeURIComponent(
      event.description
    )}&location=${encodeURIComponent(
      event.location
    )}&dates=${encodeURIComponent(event.startTime)}/${encodeURIComponent(
      event.endTime
    )}`;

    // Open the Google Calendar link in a new tab
    window.open(googleCalendarUrl, "_blank");

    // // Update reminder state
    // const newReminderState = [...isReminderSet];
    // newReminderState[index] = true;
    // setIsReminderSet(newReminderState);

    // Show a toast notification
    toast({
      title: "Reminder Set",
      description: `You've set a reminder for ${service.name} on ${service.day}s at ${service.startTime}.`,
    });
  };

  return (
    <section className="py-12 bg-gray-50">
      <div className="container mx-auto px-4">
        <h2 className="text-3xl font-bold text-center mb-8">
          Join Us in Worship
        </h2>
        <Card className="max-w-3xl mx-auto">
          <CardHeader>
            <CardTitle className="text-2xl text-center">
              Regular Service Times
            </CardTitle>
          </CardHeader>
          <CardContent>
            <div className="grid gap-6 md:grid-cols-2">
              {services.map((service, index) => (
                <div key={index} className="flex items-start space-x-4">
                  <div className="bg-primary rounded-full p-2 text-primary-foreground">
                    {service.day === "Sunday" ? (
                      <Calendar className="h-6 w-6" />
                    ) : (
                      <Clock className="h-6 w-6" />
                    )}
                  </div>
                  <div className="flex-grow">
                    <h3 className="font-semibold text-lg">{service.name}</h3>
                    <p className="text-muted-foreground">
                      {service.day}s at {service.startTime} - {service.endTime}
                    </p>
                    <Button
                      variant="outline"
                      size="sm"
                      className="mt-2"
                      onClick={() => addToCalendar(index)}
                      disabled={isReminderSet[index]}
                    >
                      <Bell className="h-4 w-4 mr-2" />
                      {isReminderSet[index] ? "Reminder Set" : "Set Reminder"}
                    </Button>
                  </div>
                </div>
              ))}
            </div>
            <div className="mt-8 text-center">
              <p className="flex items-center justify-center text-muted-foreground">
                <MapPin className="h-5 w-5 mr-2" />
                2-4 Reeders St, Haddon, JHB South 2190
              </p>
            </div>
          </CardContent>
        </Card>
      </div>
    </section>
  );
}
