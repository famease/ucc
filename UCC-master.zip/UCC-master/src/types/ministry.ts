export type Event = {
  title: string;
  date: string;
  description: string;
};

export type Ministry = {
  name: string;
  image: string;
  link: string;
  description: string;
  activities: string[];
  events: Event[];
};

export const ministries: Ministry[] = [
//missions
{
  name: "UCC missions",
  image: "/missions-logo.webp?height=300&width=400",
  link: "/ministries/missions",
  description:
    "UCC missions is a ministry that empowers youth to be strong and courageous in their faith.",
  activities: ["Bible Study", "Prayer Meeting", "Outreach"],
  events: [
    {
      title: "Youth Retreat",
      date: "2024-06-10",
      description:
        "A weekend retreat for youth to connect with God and each other.",
    },
  ],
}, //celebrate recovery
{
  name: "Celebrate Recovery",
  image: "/crlogo.jpg?height=300&width=400",
  link: "/ministries/cr",
  description:
    "Celebrate Recovery is a ministry that empowers youth to be strong and courageous in their faith.",
  activities: ["Bible Study", "Prayer Meeting", "Outreach"],
  events: [
    {
      title: "Youth Retreat",
      date: "2024-06-10",
      description:
        "A weekend retreat for youth to connect with God and each other.",
    },
  ],
  },
  //brothers
  {
    name: "The Gideonite Order",
    image: "/mens-logo.jpg?height=300&width=400",

    link: "/ministries/brothers",
    description: 
      "The Gideonite Order is a ministry that empowers youth to be strong and courageous in their faith.",
    activities: ["Bible Study", "Prayer Meeting", "Outreach"],
    events: [
      {
        title: "Youth Retreat",
        date: "2024-06-10",
        description:
          "A weekend retreat for youth to connect with God and each other.",
      },
    ],
  },

  //Women
  {
    name: "Women of valor",
    image: "/wov-logo.jpg?height=300&width=400",
    link: "/ministries/wov",
    description:
      "Women of valor is a ministry that empowers women to be strong and courageous in their faith.",
    activities: ["Bible Study", "Prayer Meeting", "Outreach"],
    events: [
      {
        title: "Women's Retreat",
        date: "2024-05-15",
        description:
          "A weekend retreat for women to connect with God and each other.",
      },
    ],
  },

  //youth
  {
    name: "One2Nine Generation",
    image: "/One2Nine.webp?height=300&width=400",
    link: "/ministries/youth",
    description:
      "One2Nine Generation is a ministry that empowers youth to be strong and courageous in their faith.",
    activities: ["Bible Study", "Prayer Meeting", "Outreach"],
    events: [
      {
        title: "Youth Retreat",
        date: "2024-06-10",
        description:
          "A weekend retreat for youth to connect with God and each other.",
      },
    ],
  },
  


  //sunday school;
  {
    name: "Sunday School",
    image: "/sunday-school.webp?height=300&width=400",

    link: "/ministries/sunday-school",
    description:
      "Sunday School is a ministry that empowers youth to be strong and courageous in their faith.",
    activities: ["Bible Study", "Prayer Meeting", "Outreach"],
    events: [
      {
        title: "Youth Retreat",
        date: "2024-06-10",
        description:
          "A weekend retreat for youth to connect with God and each other.",
      },
    ],
  },

 
];
