import React from "react";
import DonationPage from "./Tithes";
import { Metadata } from "next";

export const metadata: Metadata = {
  title: "Tithes & Offering | Support Our Ministry",
  description:
    "Support the ministry of Upperroom Christian Center through tithes and offerings. Multiple giving options available.",
  keywords: [
    "church giving",
    "online tithing",
    "church donations JHB",
    "UCC Tithes",
    "UCC missions ministry",
    "feed children weekly",
    "church information",
    "make donations",
    "banking details",
    "church times",
    "ministries"
  ],
  openGraph: {
    title: "Tithes & Offering | Support Our Ministry",
    description:
      "Support the ministry of Upperroom Christian Center through tithes and offerings. Multiple giving options available.",
    url: "https://urcc.co.za/tithes",
    type: "website",
    locale: "en_ZA",
  },
};

function page() {
  return (
    <div>
      <DonationPage />
    </div>
  );
}

export default page;
