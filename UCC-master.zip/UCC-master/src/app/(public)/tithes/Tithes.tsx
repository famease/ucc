import { Metadata } from "next";
import CharityDonationForm from "@/components/charity-donation-form";
import ChurchOfferingForm from "@/components/church-offering-form";
import PhysicalDonations from "@/components/physical-donations";
import ContactInfo from "@/components/contact-info";
import { Alert, AlertDescription, AlertTitle } from "@/components/ui/alert";
import { ShieldCheck } from "lucide-react";
import ChurchBankingDetails from "@/components/church-banking-details";
import TithesAndOfferingInfo from "@/components/tithes-info";
import MissionsBankInfo from "@/components/missions-form";

// Metadata configuration
export const metadata: Metadata = {
  title: "Support Our Church | Tithes & Offerings",
  description:
    "Support Upperroom Christian Center with tithes, offerings, and donations. Your generosity helps us serve the community and spread the gospel.",
  keywords: [
    "church donations",
    "tithes and offerings",
    "support UCC",
    "donate to church",
    "UCC missions ministry",
    "feed children weekly",
    "church information",
    "make donations",
    "banking details",
    "church times",
    "ministries",
  ],
  openGraph: {
    title: "Support Our Church | Tithes & Offerings",
    description:
      "Support Upperroom Christian Center with tithes, offerings, and donations. Your generosity helps us serve the community and spread the gospel.",
    url: "https://urcc.co.za/tithes",
    type: "website",
    locale: "en_ZA",
  },
};

export default function DonationPage() {
  return (
    <div className="container mx-auto px-4 py-8">
      <h1 className="text-3xl font-bold text-center mb-8">
        Support Our Church
      </h1>
      <div className="grid gap-8 md:grid-cols-2">
        <TithesAndOfferingInfo />
        <MissionsBankInfo />
      </div>
      {/* <ChurchBankingDetails /> */}
      <PhysicalDonations />
      <ContactInfo />
    </div>
  );
}
