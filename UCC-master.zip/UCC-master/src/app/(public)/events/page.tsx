import React from 'react';
import { Metadata } from "next";

// Metadata configuration
export const metadata: Metadata = {
  title: "UCC Events | Upcoming and Past Events",
  description:
    "Stay updated with our upcoming and past events at Upperroom Christian Center. Join us for worship, fellowship, and community service.",
  keywords: [
    "UCC events",
    "church events",
    "upcoming events",
    "past events",
    "UCC missions ministry",
    "feed children weekly",
    "church information",
    "make donations",
    "banking details",
    "church times",
    "ministries"
  ],
  openGraph: {
    title: "UCC Events | Upcoming and Past Events",
    description:
      "Stay updated with our upcoming and past events at Upperroom Christian Center. Join us for worship, fellowship, and community service.",
    url: "https://urcc.co.za/events",
    type: "website",
    locale: "en_ZA",
  },
};

function page() {
  return (
    <div>page</div>
  );
}

export default page;
