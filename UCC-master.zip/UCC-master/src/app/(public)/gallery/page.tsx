import React from 'react';
import { Metadata } from "next";

// Metadata configuration
export const metadata: Metadata = {
  title: "UCC Gallery | Photos from Our Ministry",
  description:
    "Explore our gallery to see photos from our various ministries and events at Upperroom Christian Center.",
  keywords: [
    "UCC gallery",
    "ministry photos",
    "church events",
    "UCC missions ministry",
    "feed children weekly",
    "church information",
    "make donations",
    "banking details",
    "church times",
    "ministries"
  ],
  openGraph: {
    title: "UCC Gallery | Photos from Our Ministry",
    description:
      "Explore our gallery to see photos from our various ministries and events at Upperroom Christian Center.",
    url: "https://urcc.co.za/gallery",
    type: "website",
    locale: "en_ZA",
  },
};

function page() {
  return (
    <div>page</div>
  );
}

export default page;
