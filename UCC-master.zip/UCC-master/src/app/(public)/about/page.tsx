import React from "react";
import AboutUs from "@/components/about-us";
import { Metadata } from "next";

export const metadata: Metadata = {
  title: "About Our Church | History & Mission",
  description:
    "Learn about Upperroom Christian Center's history, mission, and our commitment to serving the Haddon Community, community.",
  keywords: [
    "about Upperroom Christian Center",
    "church history Haddon",
    "church mission JHB South",
    "Christian church Bellavista",
  ],
};
const page = () => {
  return (
    <div>
      <AboutUs />
    </div>
  );
};

export default page;
