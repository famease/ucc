import React from "react";
import WomensMinistry from "./WOV";

function WOV() {
  return (
    <div>
      <WomensMinistry />
    </div>
  );
}

export default WOV;
