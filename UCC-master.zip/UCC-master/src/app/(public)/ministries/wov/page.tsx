import Image from "next/image";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import {
  Heart,
  Star,
  Users,
  Anchor,
  Sun,
  TreesIcon as Tree,
} from "lucide-react";

export default function WomensMinistry() {
  return (
    <div className="min-h-screen bg-background text-foreground">
      <header className="bg-primary text-primary-foreground py-20 relative overflow-hidden">
        <div className="absolute inset-0 bg-[url('/cross.webp?height=400&width=1200')] bg-cover bg-center opacity-20"></div>
        <div className="container mx-auto px-4 relative z-10">
          <h1 className="text-5xl md:text-7xl font-extrabold mb-4 leading-tight">
            Women of Valor
          </h1>
          <p className="text-xl md:text-2xl font-medium max-w-2xl">
            Empowered by faith, transforming the world with grace
          </p>
        </div>
      </header>

      <main className="container mx-auto px-4 py-16">
        <section className="mb-20">
          <div className="max-w-3xl mx-auto text-center">
            <h2 className="text-3xl md:text-4xl font-bold mb-6 text-foreground">
              The Legacy of Valor
            </h2>
            <p className="text-lg text-muted-foreground mb-8">
              From Deborah&#39;s leadership to Esther&#39;s courage, from
              Mary&#39;s faithfulness to Priscilla&#39;s teaching, we stand on
              the shoulders of women who changed the course of history through
              their faith and actions. Today, we continue their legacy.
            </p>
            {/* <div className="flex justify-center">
              <Button className="text-lg px-6 py-3 bg-primary text-primary-foreground hover:bg-primary/90">
                Discover Your Calling
              </Button>
            </div> */}
          </div>
        </section>

        <section className="mb-20">
          <h2 className="text-3xl md:text-4xl font-bold mb-8 text-center text-foreground">
            Our Pillars of Strength
          </h2>
          <div className="grid grid-cols-1 md:grid-cols-3 gap-8">
            {[
              {
                icon: Heart,
                title: "Compassion",
                description:
                  "Extending God's love to our families, community, and the world.",
              },
              {
                icon: Star,
                title: "Courage",
                description:
                  "Standing firm in faith, even in the face of adversity.",
              },
              {
                icon: Anchor,
                title: "Wisdom",
                description:
                  "Grounding our lives in God's truth and sharing it with others.",
              },
            ].map((item, index) => (
              <Card key={index} className="bg-card text-card-foreground">
                <CardHeader>
                  <CardTitle className="flex items-center text-xl">
                    <item.icon className="mr-3 h-6 w-6 text-primary" />
                    {item.title}
                  </CardTitle>
                </CardHeader>
                <CardContent>
                  <p className="text-muted-foreground">{item.description}</p>
                </CardContent>
              </Card>
            ))}
          </div>
        </section>

        <section className="mb-20 bg-muted p-8 rounded-lg">
          <h2 className="text-3xl md:text-4xl font-bold mb-8 text-center text-foreground">
            The Woman of Valor
          </h2>
          <div className="max-w-3xl mx-auto text-center">
            <p className="text-lg italic text-muted-foreground">
              &#34;Strength and dignity are her clothing,
              <br />
              And she smiles at the future.
              <br />
              She opens her mouth in wisdom,
              <br />
              And the teaching of kindness is on her tongue.
              <br />
              She looks well to the ways of her household,
              <br />
              And does not eat the bread of idleness.
              <br />
              Charm is deceitful and beauty is vain,
              <br />
              But a woman who fears the Lord, she shall be praised.&#34;
              <br />- Proverbs 31:25-27, 30
            </p>
          </div>
        </section>

        <section className="mb-20">
          <h2 className="text-3xl md:text-4xl font-bold mb-8 text-center text-foreground">
            Nurturing Our Faith
          </h2>
          <div className="grid grid-cols-1 md:grid-cols-2 gap-8">
            {[
              {
                title: "Garden of Grace",
                description:
                  "Weekly Bible studies where we cultivate our knowledge and love for God's Word.",
                icon: Tree,
              },
              {
                title: "Threads of Fellowship",
                description:
                  "Monthly gatherings for worship, prayer, and building lasting friendships.",
                icon: Users,
              },
              {
                title: "Hands of Mercy",
                description:
                  "Outreach programs where we extend God's love through acts of service.",
                icon: Heart,
              },
              {
                title: "Wellsprings Retreat",
                description:
                  "Annual getaway for spiritual refreshment and deeper connections.",
                icon: Sun,
              },
            ].map((item, index) => (
              <Card key={index} className="bg-card text-card-foreground">
                <CardHeader>
                  <CardTitle className="flex items-center text-xl">
                    <item.icon className="mr-3 h-6 w-6 text-primary" />
                    {item.title}
                  </CardTitle>
                </CardHeader>
                <CardContent>
                  <p className="text-muted-foreground">{item.description}</p>
                </CardContent>
              </Card>
            ))}
          </div>
        </section>

        <section className="mb-20">
          <h2 className="text-3xl md:text-4xl font-bold mb-8 text-center text-foreground">
            Our Tapestry of Faith
          </h2>
          <div className="relative h-96 rounded-lg overflow-hidden">
            <Image
              src="/women1.webp?height=400&width=1200"
              alt="Women worshipping together"
              layout="fill"
              objectFit="cover"
              className="rounded-lg"
            />
            <div className="absolute inset-0 bg-gradient-to-t from-blue-600 to-transparent bg-opacity-60"></div>
            <div className="absolute bottom-0 left-0 right-0 p-8 text-center">
              <p className="text-2xl font-bold text-primary-foreground mb-4">
                &#34;I can do all things through Christ who strengthens me.&#34;
                - Philippians 4:13
              </p>
              {/* <Button className="bg-primary text-primary-foreground hover:bg-primary/90">
                Share Your Story
              </Button> */}
            </div>
          </div>
        </section>

        <section className="mb-20">
          <h2 className="text-3xl md:text-4xl font-bold mb-8 text-center text-foreground">
            Women of Valor in Action
          </h2>
          <div className="grid grid-cols-1 md:grid-cols-2 gap-8">
            <div className="relative h-64 rounded-lg overflow-hidden">
              <Image
                src="/women2.webp?height=300&width=400"
                alt="Women engaged in Bible study"
                layout="fill"
                objectFit="cover"
                className="rounded-lg"
              />
              <div className="absolute inset-0 bg-gradient-to-t from-blue-600 to-transparent bg-opacity-60"></div>

              <div className="absolute bottom-0 left-0 right-0 p-4">
                <p className="text-lg font-semibold text-primary-foreground">
                  Cultivating Wisdom in our community
                </p>
              </div>
            </div>
            <div className="relative h-64 rounded-lg overflow-hidden">
              <Image
                src="/women3.webp?height=350&width=400"
                alt="Women serving at a community outreach event"
                layout="fill"
                objectFit="cover"
                className="rounded-lg"
              />
              <div className="absolute inset-0 bg-gradient-to-t from-blue-600 to-transparent bg-opacity-60"></div>
              <div className="absolute bottom-0 left-0 right-0 p-4">
                <p className="text-lg font-semibold text-primary-foreground">
                  Hands of Mercy: Serving Our Community
                </p>
              </div>
            </div>
          </div>
        </section>
      </main>
    </div>
  );
}
