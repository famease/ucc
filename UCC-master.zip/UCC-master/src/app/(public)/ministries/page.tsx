import React from "react";
import { Metadata } from "next";
import Ministries from "./Ministries";

export const metadata: Metadata = {
  title: "Church Ministries & Programs",
  description:
    "Explore our diverse ministries including One2Nine Generation, UCC Missions, Women of Valor, and Celebrate Recovery programs.",
  keywords: [
    "church ministries Haddon",
    "ministries in Johannesburg",
    "Christian programs JHB",
    "Celebrate Recovery",
    "UCC missions ministry",
    "feed children weekly",
    "church information",
    "make donations",
    "banking details",
    "church times",
    "ministries"
  ],
  openGraph: {
    title: "Church Ministries & Programs",
    description:
      "Explore our diverse ministries including One2Nine Generation, UCC Missions, Women of Valor, and Celebrate Recovery programs.",
    url: "https://urcc.co.za/ministries",
    type: "website",
    locale: "en_ZA",
  },
};

function page() {
  return (
    <div>
      <Ministries />
    </div>
  );
}

export default page;
