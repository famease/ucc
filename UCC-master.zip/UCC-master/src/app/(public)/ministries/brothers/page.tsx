import Image from "next/image";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Book, Users, Mountain, Flame } from "lucide-react";

export default function MensMinistry() {
  return (
    <div className="min-h-screen bg-background text-foreground">
      <header className="bg-primary text-primary-foreground py-20 relative overflow-hidden">
        <div className="absolute inset-0 bg-[url('/cross.webp?height=400&width=1200')] bg-cover bg-center opacity-20"></div>
        <div className="container mx-auto px-4 relative z-10">
          <h1 className="text-5xl md:text-7xl font-extrabold mb-4 leading-tight">
          The Gideonite Order
          </h1>
          <p className="text-xl md:text-2xl font-medium max-w-2xl">
            Building a community of Godly men who lead with faith, serve with
            love, and inspire with integrity.
          </p>
        </div>
      </header>

      <main className="container mx-auto px-4 py-16">
        <section className="mb-20">
          <div className="max-w-3xl mx-auto text-center">
            <h2 className="text-3xl md:text-4xl font-bold mb-6 text-foreground">
              Our Mission
            </h2>
            <p className="text-lg text-muted-foreground mb-8">
              The Gideonite Order is dedicated to nurturing men to be Godly
              leaders, loving fathers, and pillars of their communities.
              Together, we strive to grow in Christ and reflect His character in
              every aspect of our lives.
            </p>
          </div>
        </section>

        <section className="mb-20">
          <h2 className="text-3xl md:text-4xl font-bold mb-8 text-center text-foreground">
            Core Values
          </h2>
          <div className="grid grid-cols-1 md:grid-cols-3 gap-8">
            {[
              {
                icon: Book,
                title: "Faith",
                description:
                  "Rooted in God's Word, we seek to grow spiritually and lead by example.",
              },
              {
                icon: Users,
                title: "Community",
                description:
                  "We are stronger together, supporting and uplifting one another in faith and life.",
              },
              {
                icon: Mountain,
                title: "Leadership",
                description:
                  "Called to lead with humility and purpose, shaping families and communities for God's glory.",
              },
            ].map((item, index) => (
              <Card key={index} className="bg-card text-card-foreground">
                <CardHeader>
                  <CardTitle className="flex items-center text-xl">
                    <item.icon className="mr-3 h-6 w-6 text-primary" />
                    {item.title}
                  </CardTitle>
                </CardHeader>
                <CardContent>
                  <p className="text-muted-foreground">{item.description}</p>
                </CardContent>
              </Card>
            ))}
          </div>
        </section>

        <section className="mb-20 bg-muted p-8 rounded-lg">
          <h2 className="text-3xl md:text-4xl font-bold mb-8 text-center text-foreground">
            A Commitment to Growth
          </h2>
          <div className="max-w-3xl mx-auto text-center">
            <p className="text-lg italic text-muted-foreground">
              &#34;As iron sharpens iron, so one man sharpens another.&#34; -
              Proverbs 27:17
            </p>
            <p className="mt-6 text-lg text-muted-foreground">
              Our ministry is a journey of continuous spiritual, relational, and
              personal growth as we become the men God has called us to be.
            </p>
          </div>
        </section>

        <section className="mb-20">
          <h2 className="text-3xl md:text-4xl font-bold mb-8 text-center text-foreground">
            Programs & Activities
          </h2>
          <div className="grid grid-cols-1 md:grid-cols-2 gap-8">
            {[
              {
                title: "Fellowship Nights",
                description:
                  "Monthly gatherings to connect, pray, and share life's challenges and victories.",
                icon: Users,
              },
              {
                title: "Bible Study Groups",
                description:
                  "Deepen your understanding of Scripture through small-group studies.",
                icon: Book,
              },
              {
                title: "Community Outreach",
                description:
                  "Serving those in need and being a light in the community.",
                icon: Flame,
              },
              {
                title: "Retreats & Workshops",
                description:
                  "Opportunities for rest, renewal, and learning practical tools for Godly living.",
                icon: Mountain,
              },
            ].map((item, index) => (
              <Card key={index} className="bg-card text-card-foreground">
                <CardHeader>
                  <CardTitle className="flex items-center text-xl">
                    <item.icon className="mr-3 h-6 w-6 text-primary" />
                    {item.title}
                  </CardTitle>
                </CardHeader>
                <CardContent>
                  <p className="text-muted-foreground">{item.description}</p>
                </CardContent>
              </Card>
            ))}
          </div>
        </section>
        <section className="mb-20">
          <h2 className="text-3xl md:text-4xl font-bold mb-8 text-center text-foreground"></h2>
          <div className="relative h-96 rounded-lg overflow-hidden">
            <Image
              src="/brothers1.webp?height=400&width=1200"
              alt="Men Group Photo"
              layout="fill"
              objectFit="cover"
              className="rounded-lg"
            />
            <div className="absolute inset-0 bg-gradient-to-t from-blue-600 to-transparent bg-opacity-60"></div>

            <div className="absolute bottom-0 left-0 right-0 p-8 text-center">
              <p className="text-2xl font-bold text-primary-foreground mb-4">
                &#34;The battle is not yours, but God&#39;s.&#34; - 2 Chronicles
                20:15
              </p>
              {/* <Button className="bg-primary text-primary-foreground hover:bg-primary/90">
                Prepare for Battle
              </Button> */}
            </div>
          </div>
        </section>
        <section className="mb-20">
          <h2 className="text-3xl md:text-4xl font-bold mb-8 text-center text-foreground">
            Gideonites
          </h2>
          <div className="grid grid-cols-1 md:grid-cols-2 gap-8">
            <div className="relative h-64 rounded-lg overflow-hidden">
              <Image
                src="/brothers.webp?height=300&width=400"
                alt="Men's group engaged in Bible study"
                layout="fill"
                objectFit="cover"
                className="rounded-lg"
              />
              <div className="absolute inset-0 bg-gradient-to-t from-blue-600 to-transparent bg-opacity-60"></div>

              <div className="absolute bottom-0 left-0 right-0 p-4">
                <p className="text-lg font-semibold text-primary-foreground">
                  Iron Sharpens Iron
                </p>
              </div>
            </div>
            <div className="relative h-64 rounded-lg overflow-hidden">
              <Image
                src="/brothers2.webp?height=300&width=400"
                alt="Men serving at a community outreach event"
                layout="fill"
                objectFit="cover"
                className="rounded-lg"
              />
              <div className="absolute inset-0 bg-gradient-to-t from-blue-600 to-transparent bg-opacity-60"></div>
              <div className="absolute bottom-0 left-0 right-0 p-4">
                <p className="text-lg font-semibold text-primary-foreground">
                  Community Impact
                </p>
              </div>
            </div>
          </div>
        </section>
      </main>
    </div>
  );
}
