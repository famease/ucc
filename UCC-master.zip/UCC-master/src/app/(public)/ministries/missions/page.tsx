import Image from "next/image";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import Link from "next/link";
import { Metadata } from "next";

export const metadata: Metadata = {
  title: "UCC Missions | Nourishing Bodies, Uplifting Spirits, Transforming Lives",
  description:
    "At UCC Missions, we're dedicated to nourishing both body and soul. Our core mission is to provide sustenance to those in need in our community.",
  keywords: [
    "UCC Missions",
    "feeding young minds",
    "daily bread",
    "transforming lives",
    "UCC missions ministry",
    "feed children weekly",
    "church information",
    "make donations",
    "banking details",
    "church times",
    "ministries"
  ],
  openGraph: {
    title: "UCC Missions | Nourishing Bodies, Uplifting Spirits, Transforming Lives",
    description:
      "At UCC Missions, we're dedicated to nourishing both body and soul. Our core mission is to provide sustenance to those in need in our community.",
    url: "https://urcc.co.za/ministries/missions",
    type: "website",
    locale: "en_ZA",
  },
};

export default function Home() {
  return (
    <div className="min-h-screen bg-gray-100">
      <header className="bg-blue-600 text-white py-12">
        <div className="container mx-auto px-4 text-center">
          <h1 className="text-5xl font-bold mb-4">UCC Missions</h1>
          <p className="text-2xl">
            Nourishing Bodies, Uplifting Spirits, Transforming Lives
          </p>
        </div>
      </header>

      <main className="container mx-auto px-4 py-12">
        <section className="mb-16">
          <h2 className="text-3xl font-semibold mb-6 text-center">
            Our Mission
          </h2>
          <div className="flex flex-col md:flex-row items-center gap-8">
            <div className="md:w-1/2">
              <p className="text-lg leading-relaxed">
                At UCC Missions, we&#39;re dedicated to nourishing both body and
                soul. Our core mission is to provide sustenance to those in need
                in our community. We go beyond just providing food by offering
                counseling and spiritual guidance to heal hearts and restore
                lives.
              </p>
            </div>
            <div className="md:w-1/2">
              <Image
                src="/missions-group.webp?height=300&width=400"
                alt="missions logo"
                width={400}
                height={300}
                className="rounded-lg shadow-md"
              />
            </div>
          </div>
        </section>

        <section className="mb-16">
          <h2 className="text-3xl font-semibold mb-6 text-center">
            Our Impact
          </h2>
          <div className="grid md:grid-cols-2 gap-8">
            <Card>
              <CardHeader>
                <CardTitle className="text-2xl mb-2">
                  Feeding Young Minds
                </CardTitle>
              </CardHeader>
              <CardContent>
                <p className="text-lg mb-4">
                  Every Tuesday, we bring smiles to 150 school children by
                  providing them with nutritious, home-cooked meals. It&#39;s
                  not just about filling stomachs; it&#39;s about fueling dreams
                  and potential.
                </p>
                <Image
                  src="/missions1.webp?height=200&width=350"
                  alt="Children enjoying a meal"
                  width={350}
                  height={200}
                  className="rounded-lg"
                />
              </CardContent>
            </Card>
            <Card>
              <CardHeader>
                <CardTitle className="text-2xl mb-2">
                  Daily Bread, Daily Hope
                </CardTitle>
              </CardHeader>
              <CardContent>
                <p className="text-lg mb-4">
                  Our daily food parcel distribution is a lifeline for many in
                  our community. Each package is more than just food; it&#39;s a
                  tangible expression of love and support to those facing
                  hardship.
                </p>
                <Image
                  src="/missions2.webp?height=200&width=350"
                  alt="Food parcels ready for distribution"
                  width={350}
                  height={200}
                  className="rounded-lg"
                />
              </CardContent>
            </Card>
          </div>
        </section>

        <section className="mb-16">
          <h2 className="text-3xl font-semibold mb-6 text-center">
            Transforming Lives
          </h2>
          <div className="bg-white p-8 rounded-lg shadow-md">
            <p className="text-lg mb-6">
              The true power of UCC Missions lies in the lives we&#39;ve touched
              and transformed. Many who once stood in our food lines now stand
              beside us as active members of our church and community, their
              lives restored and renewed.
            </p>
            <blockquote className="border-l-4 border-blue-600 pl-4 italic text-xl">
            &#34;UCC Missions didn&#39;t just feed me; they nourished my soul
              and gave me a new lease on life. Today, I&#39;m proud to give back
              to the community that once supported me.&#34;
              <footer className="text-right mt-2 text-gray-600">
                - Mr S., Former Recipient
              </footer>
            </blockquote>
          </div>
        </section>

        <section className="mb-16">
          <h2 className="text-3xl font-semibold mb-6 text-center">
            Who We Serve
          </h2>
          <div className="flex flex-col md:flex-row items-center gap-8">
            <div className="md:w-1/2">
              <Image
                src="/missions3.webp?height=300&width=400"
                alt="Community members receiving assistance"
                width={400}
                height={300}
                className="rounded-lg shadow-md"
              />
            </div>
            <div className="md:w-1/2">
              <p className="text-lg leading-relaxed">
                Our heart beats for the most vulnerable in our community:
              </p>
              <ul className="list-disc list-inside text-lg mt-4 space-y-2">
                <li>Children from low-income families</li>
                <li>Elderly individuals on fixed incomes</li>
                <li>Families struggling to make ends meet</li>
                <li>Individuals facing temporary financial hardship</li>
              </ul>
              <p className="text-lg mt-4">
                We believe that by addressing food insecurity, we can help our
                community members focus on improving other aspects of their
                lives, breaking the cycle of poverty.
              </p>
            </div>
          </div>
        </section>

        <section className="mb-16">
          <h2 className="text-3xl font-semibold mb-6 text-center">
            Our Vision for the Future
          </h2>
          <Card>
            <CardContent className="p-6">
              <p className="text-lg mb-4">
                As we look to the horizon, our hearts are filled with hope and
                ambition to do even more:
              </p>
              <ul className="list-disc list-inside text-lg space-y-2 mb-6">
                <li>
                  Expand our reach to communities in southern Johannesburg
                </li>
                <li>
                  Establish a sustainable stipend program for our dedicated
                  volunteers
                </li>
                <li>
                  Launch nutritional education programs to promote healthier
                  eating habits
                </li>
                <li>
                  Create a community garden to promote self-sustainability and
                  fresh produce access
                </li>
              </ul>
              <p className="text-lg italic">
                &#34;With your support, we can turn these dreams into reality,
                touching more lives and spreading more hope.&#34;
              </p>
            </CardContent>
          </Card>
        </section>

        <section className="mb-16">
          <h2 className="text-3xl font-semibold mb-6 text-center">
            Join Our Mission
          </h2>
          <div className="text-center">
            <p className="text-xl mb-6">
              Your hands, heart, and resources can make a world of difference.
              Here&#39;s how you can get involved:
            </p>
            <div className="flex flex-wrap justify-center gap-4">
              <Button size="lg" className="text-lg px-8">
                <a href="mailto:uccjhbsouth@gmail.coms">Volunteer</a>
              </Button>
              <Button size="lg" variant="outline" className="text-lg px-8">
                <Link href="/tithes">Donate</Link>
              </Button>
            </div>
            <p className="mt-6 text-lg">
              Contact Randolph Beyers to learn more about how you can contribute
              to our mission.
            </p>
          </div>
        </section>
      </main>

      <footer className="bg-gray-800 text-white py-8">
        <div className="container mx-auto px-4">
          <div className="flex flex-col md:flex-row justify-between items-center">
            <div className="mb-4 md:mb-0">
              <h3 className="text-2xl font-semibold mb-2">UCC Missions</h3>
              <p>Transforming lives, one meal at a time</p>
            </div>
            <div className="text-center md:text-right">
              <p className="mb-2">Contact: Randolph Beyers</p>
              <p className="mb-2">Phone: 078 070 0179</p>
            </div>
          </div>
        </div>
      </footer>
    </div>
  );
}
