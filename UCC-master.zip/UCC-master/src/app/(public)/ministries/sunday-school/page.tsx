import Image from "next/image";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Calendar, Clock, MapPin, Mail, Phone, Users } from "lucide-react";
import Link from "next/link";

export default function SundaySchool() {
  return (
    <div className="min-h-screen bg-gray-100">
      <header className="bg-blue-700 text-white py-12 relative overflow-hidden">
        <Image
          src="/cross.webp?height=400&width=1200"
          alt="Children in Sunday School"
          width={1200}
          height={400}
          className="absolute inset-0 object-cover opacity-20"
        />
        <div className="container mx-auto px-4 text-center relative z-10">
          <h1 className="text-5xl font-bold mb-4">Sunday School</h1>
          <p className="text-2xl">
            Nurturing young hearts and minds in faith every Sunday
          </p>
        </div>
      </header>

      <main className="container mx-auto px-4 py-12">
        <section className="mb-16">
          <h2 className="text-3xl font-semibold mb-6 text-center">
            About Our Sunday School
          </h2>
          <div className="flex flex-col md:flex-row items-center gap-8">
            <div className="md:w-1/2">
              <p className="text-lg leading-relaxed">
                Our Sunday School is a vibrant and engaging program where
                children learn about God&#39;s love and the teachings of Jesus
                Christ. Every Sunday, we come together to explore Bible stories,
                sing joyful songs, and participate in fun activities that
                reinforce our faith.
              </p>
              <p className="text-lg leading-relaxed mt-4">
                We believe in nurturing young minds and hearts, helping them
                build a strong foundation in their spiritual journey. Our
                dedicated teachers create a welcoming and inclusive environment
                where every child can grow in their understanding of God&#39;s
                word.
              </p>
            </div>
            <div className="md:w-1/2">
              <Image
                src="/sunday-school.webp?height=300&width=400"
                alt="Children engaged in Sunday School activities"
                width={400}
                height={300}
                className="rounded-lg shadow-md"
              />
            </div>
          </div>
        </section>

        <section className="mb-16">
          <h2 className="text-3xl font-semibold mb-6 text-center">
            What We Do
          </h2>
          <div className="grid md:grid-cols-3 gap-6 max-w-4xl mx-auto">
            <Card>
              <CardHeader>
                <CardTitle className="flex items-center">
                  <Users className="mr-2 h-6 w-6 text-blue-500" />
                  Learn Together
                </CardTitle>
              </CardHeader>
              <CardContent>
                <p>
                  Explore Bible stories and their meanings in interactive
                  lessons.
                </p>
              </CardContent>
            </Card>
            <Card>
              <CardHeader>
                <CardTitle className="flex items-center">
                  <Calendar className="mr-2 h-6 w-6 text-blue-500" />
                  Attend Church
                </CardTitle>
              </CardHeader>
              <CardContent>
                <p>
                  Participate in age-appropriate worship services every Sunday.
                </p>
              </CardContent>
            </Card>
            <Card>
              <CardHeader>
                <CardTitle className="flex items-center">
                  <Users className="mr-2 h-6 w-6 text-blue-500" />
                  Build Community
                </CardTitle>
              </CardHeader>
              <CardContent>
                <p>
                  Foster friendships and create a supportive faith community.
                </p>
              </CardContent>
            </Card>
          </div>
        </section>

        <section className="mb-16">
          <h2 className="text-3xl font-semibold mb-6 text-center">
            Sunday School Schedule
          </h2>
          <Card className="max-w-2xl mx-auto">
            <CardContent className="p-6">
              <div className="flex items-center mb-4">
                <Calendar className="mr-2 h-5 w-5 text-blue-500" />
                <span className="text-lg">Every Sunday</span>
              </div>
              <div className="flex items-center mb-4">
                <Clock className="mr-2 h-5 w-5 text-blue-500" />
                <span className="text-lg">10:30 AM - 12:30 AM</span>
              </div>
              <div className="flex items-center">
                <MapPin className="mr-2 h-5 w-5 text-blue-500" />
                <span className="text-lg">
                  Church Building, Children&#39;s Wing
                </span>
              </div>
            </CardContent>
          </Card>
        </section>

        <section className="mb-16">
          <h2 className="text-3xl font-semibold mb-6 text-center">
            Contact Our Sunday School Coordinator
          </h2>
          <Card className="max-w-2xl mx-auto">
            <CardHeader>
              <CardTitle className="flex items-center justify-center">
                <Users className="mr-2 h-6 w-6 text-blue-500" />
                Sister Myrtle Moody
              </CardTitle>
            </CardHeader>
            <CardContent className="p-6">
              <div className="flex items-center justify-center mb-4">
                <Mail className="mr-2 h-5 w-5 text-blue-500" />
                <a
                  href="mailto:myrtle.jhn316@gmail.com"
                  className="text-blue-600 hover:underline"
                >
                  myrtle.jhn316@gmail.com
                </a>
              </div>
              {/* <div className="flex items-center justify-center">
                <Phone className="mr-2 h-5 w-5 text-blue-500" />
                <a href="tel:+27780700179" className="text-blue-600 hover:underline">078 070 0179</a>
              </div> */}
            </CardContent>
          </Card>
        </section>

        <section className="mb-16">
          <h2 className="text-3xl font-semibold mb-6 text-center">
            Join Us This Sunday!
          </h2>
          <div className="text-center max-w-3xl mx-auto">
            <p className="text-lg mb-6">
              We welcome all children to join our Sunday School program. No
              pre-registration is required. Simply come to the Children&#39;s
              Wing of the main church building before the service starts at
              10:30 AM every Sunday.
            </p>
            <Button size="lg" className="text-lg px-8">
              <Link href="/contact" className="flex items-center">
                Contact Us for More Information
              </Link>
            </Button>
          </div>
        </section>
      </main>
    </div>
  );
}
