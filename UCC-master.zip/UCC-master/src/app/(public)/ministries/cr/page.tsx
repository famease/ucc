import Image from "next/image";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import {
  Calendar,
  Clock,
  MapPin,
  Mail,
  Heart,
  Users,
  BookOpen,
  Lightbulb,
  Award,
  ChevronRight,
} from "lucide-react";
import {
  RiBeerFill,
  RiBodyScanFill,
  RiCake2Fill,
  RiDice6Fill,
  RiDislikeFill,
  RiDislikeLine,
  RiEmotionUnhappyFill,
  RiErrorWarningFill,
  RiHeartsFill,
  RiMedicineBottleFill,
  RiSearchEyeFill,
  RiSpyFill,
} from "@remixicon/react";
import { Metadata } from "next";

// Enhanced metadata
export const metadata: Metadata = {
  title: "Celebrate Recovery Johannesburg | Christ-Centered Recovery Program",
  description:
    "Join our Christ-centered recovery program at Upperroom Christian Center, Haddon. Every Friday 18:30. Support for addiction, trauma, and life challenges. Free, confidential meetings.",
  keywords: [
    "Celebrate Recovery Johannesburg",
    "Christian recovery program",
    "addiction recovery JHB South",
    "support group Haddon",
    "Christ-centered recovery",
    "trauma support Johannesburg",
    "recovery meetings Haddon",
    "addiction help Christian",
    "CR meetings Johannesburg South",
    "spiritual recovery program",
    "UCC missions ministry",
    "feed children weekly",
    "church information",
    "make donations",
    "banking details",
    "church times",
    "ministries"
  ],
  openGraph: {
    title: "Celebrate Recovery Program | Upperroom Christian Center",
    description:
      "Christ-centered recovery program in Haddon, Johannesburg. Free weekly meetings every Friday at 18:30.",
    url: "https://urcc.co.za/ministries/cr",
    type: "website",
    locale: "en_ZA",
    images: [
      {
        url: "/crlogo.jpg",
        width: 200,
        height: 300,
        alt: "Celebrate Recovery Program Logo",
      },
    ],
  },
};

// Add this schema markup at the top of your component
const jsonLd = {
  "@context": "https://schema.org",
  "@type": "Program",
  name: "Celebrate Recovery Program",
  description:
    "A Christ-centered recovery program for all types of hurts, habits, and hang-ups",
  provider: {
    "@type": "Church",
    name: "Upperroom Christian Center",
    address: {
      "@type": "PostalAddress",
      streetAddress: "Cnr. Reeder Street & Bellavista Road",
      addressLocality: "Haddon",
      addressRegion: "Johannesburg",
      postalCode: "2190",
      addressCountry: "ZA",
    },
  },
  event: {
    "@type": "Event",
    name: "Celebrate Recovery Meeting",
    startDate: "YYYY-MM-DDT18:30",
    endDate: "YYYY-MM-DDT20:00",
    dayOfWeek: "Friday",
    location: {
      "@type": "Place",
      name: "Upperroom Christian Center",
      address: {
        "@type": "PostalAddress",
        streetAddress: "Cnr. Reeder Street & Bellavista Road",
        addressLocality: "Haddon",
        addressRegion: "Johannesburg",
        postalCode: "2190",
        addressCountry: "ZA",
      },
    },
  },
  offers: {
    "@type": "Offer",
    price: "0",
    priceCurrency: "ZAR",
    availability: "https://schema.org/InStock",
  },
  contactPoint: [
    {
      "@type": "ContactPoint",
      name: "Sister Myrtle Moody",
      email: "myrtle.jhn316@gmail.com",
      contactType: "Program Coordinator",
    },
    {
      "@type": "ContactPoint",
      name: "Mr. William & Mrs. Gcinile Mofokeng",
      email: "mokete.mofokeng111@gmail.com",
      contactType: "Program Coordinator",
    },
  ],
};

export default function CelebrateRecovery() {
  return (
    <div className="min-h-screen bg-gray-100">
      <header className="bg-blue-600 text-white py-12 relative overflow-hidden">
        <Image
          src="/cross.webp?height=400&width=1200"
          alt="People supporting each other"
          width={1200}
          height={400}
          className="absolute inset-0 object-cover opacity-20"
        />
        <div className="container mx-auto px-4 text-center relative z-10">
          <h1 className="text-5xl font-bold mb-4">Celebrate Recovery</h1>
          <p className="text-2xl">
            A Christ-centered recovery program for all types of hurts,
            habits,
            and hang-ups
          </p>
        </div>
      </header>

      <main className="container mx-auto px-4 md:px-6 py-12">
        <section className="mb-16 px-4 md:px-0">
          <h2 className="text-3xl font-semibold mb-6 text-center">
            Our Mission
          </h2>
          <div className="flex flex-col md:flex-row items-center gap-8">
            <div className="md:w-1/2">
              <p className="text-lg text-left md:text-left">
                Celebrate Recovery is a biblical and balanced program designed
                to help you overcome your hurts, habits, and hang-ups. Based on
                the actual words of Jesus rather than psychological theory, this
                recovery program is more effective in helping people change.
              </p>
            </div>
            <div className="md:w-1/2">
              <Image
                src="/crlogo.jpg?height=300&width=400"
                alt="People in a support group"
                width={200}
                height={300}
                className="rounded-lg shadow-md w-full"
              />
            </div>
          </div>
        </section>

        <section className="mb-16 px-4 md:px-0">
          <h2 className="text-3xl font-semibold mb-6 text-center">
            Who We Serve
          </h2>
          <p className="text-lg text-center max-w-3xl mx-auto mb-8">
            We welcome all people who are suffering from any form of addiction,
            including but not limited to:
          </p>
          <div className="grid grid-cols-2 md:grid-cols-4 gap-6 max-w-4xl mx-auto">
            {[
              { icon: RiBeerFill, text: "Substance abuse" },
              { icon: RiHeartsFill, text: "Relationship issues" },
              { icon: RiSearchEyeFill, text: "Pornography" },
              { icon: RiCake2Fill, text: "Eating disorders" },
              { icon: RiDice6Fill, text: "Gambling" },
              { icon: RiMedicineBottleFill, text: "Depression" },
              { icon: RiEmotionUnhappyFill, text: "Anxiety" },
              {
                icon: RiErrorWarningFill,
                text: "Other hurts, habits, and hang-ups",
              },
            ].map((item, index) => (
              <Card key={index}>
                <CardContent className="p-4 text-center">
                  <item.icon className="mx-auto mb-2 h-8 w-8 text-blue-600" />
                  <p>{item.text}</p>
                </CardContent>
              </Card>
            ))}
          </div>
        </section>

        <section className="mb-16 px-4 md:px-0">
          <h2 className="text-3xl font-semibold mb-6 text-center">
            Meeting Information
          </h2>
          <Card className="max-w-2xl mx-auto">
            <CardContent className="p-6">
              <div className="flex items-center mb-4">
                <Calendar className="mr-2 h-5 w-5 text-blue-600" />
                <span className="text-lg">Every Friday</span>
              </div>
              <div className="flex items-center mb-4">
                <Clock className="mr-2 h-5 w-5 text-blue-600" />
                <span className="text-lg">18:30 - 20:00</span>
              </div>
              <div className="flex items-center">
                <MapPin className="mr-2 h-5 w-5 text-blue-600" />
                <span className="text-lg">
                  Upper Room Church, Cnr. Reeder Street & Bellavista Road,
                  Haddon, Johannesburg
                </span>
              </div>
            </CardContent>
          </Card>
        </section>

        <section className="mb-16 px-4 md:px-0">
          <h2 className="text-3xl font-semibold mb-6 text-center">
            What We Address
          </h2>
          <div className="grid md:grid-cols-2 gap-6 max-w-4xl mx-auto">
            <Card>
              <CardHeader>
                <CardTitle className="flex items-center">
                  <RiDislikeLine className="mr-2 h-6 w-6 text-blue-600" />
                  Hurts
                </CardTitle>
              </CardHeader>
              <CardContent>
                <ul className="list-disc list-inside">
                  <li>Divorce</li>
                  <li>Death and bereavement</li>
                  <li>Rejection</li>
                  <li>All forms of abuse</li>
                  <li>All forms of trauma</li>
                </ul>
              </CardContent>
            </Card>
            <Card>
              <CardHeader>
                <CardTitle className="flex items-center">
                  <RiDislikeFill className="mr-2 h-6 w-6 text-blue-600" />
                  Hang-ups
                </CardTitle>
              </CardHeader>
              <CardContent>
                <ul className="list-disc list-inside">
                  <li>Unemployment</li>
                  <li>Retrenchment</li>
                  <li>Homelessness</li>
                  <li>Depression</li>
                  <li>Anxiety</li>
                </ul>
              </CardContent>
            </Card>
          </div>
        </section>

        <section className="mb-16 px-4 md:px-0">
          <h2 className="text-3xl font-semibold mb-6 text-center">
            Our Program
          </h2>
          <div className="max-w-3xl mx-auto">
            <p className="text-lg mb-4">During our meetings, we offer:</p>
            <ul className="grid grid-cols-1 md:grid-cols-2 gap-4">
              {[
                { icon: Heart, text: "Prayer" },
                { icon: Users, text: "Worship" },
                { icon: BookOpen, text: "8 steps & 12 steps program" },
                { icon: Users, text: "Group sessions" },
                { icon: Lightbulb, text: "Support groups" },
              ].map((item, index) => (
                <li key={index} className="flex items-center">
                  <item.icon className="mr-2 h-5 w-5 text-blue-600" />
                  <span>{item.text}</span>
                </li>
              ))}
            </ul>
          </div>
        </section>

        <section className="mb-16 px-4 md:px-0">
          <h2 className="text-3xl font-semibold mb-6 text-center">
            Success Stories
          </h2>
          <Card className="max-w-3xl mx-auto">
            <CardContent className="p-6">
              <Image
                src="/cr-group.webp?height=200&width=400"
                alt="People celebrating recovery"
                width={400}
                height={200}
                className="rounded-lg mb-4 mx-auto"
              />
              <p className="text-lg italic">
              &#34;Celebrate Recovery has been a life-changing experience for
                many of our participants. While we respect the confidentiality
                and anonymity of our members, we can share that many have found
                healing, hope, and a new path forward through our program.
                Testimonials are shared by those who have overcome their hurts,
                habits, and hang-ups, serving as a beacon of hope for others on
                their journey to recovery.&#34;
              </p>
            </CardContent>
          </Card>
        </section>

        <section className="mb-16 px-4 md:px-0">
          <h2 className="text-3xl font-semibold mb-6 text-center">Join Us</h2>
          <div className="text-center max-w-3xl mx-auto">
            <p className="text-lg mb-6">
              Celebrate Recovery is open to anyone who needs to recover from any
              addiction. We meet every Friday, and you&#34;re welcome to join us
              at any time. No pre-registration is required.
            </p>
            <Button size="lg" className="text-lg px-8">
              <a href="#contact" className="flex items-center">
                Contact Us
                <ChevronRight className="ml-2 h-5 w-5" />
              </a>
            </Button>
          </div>
        </section>

        <section className="mb-16 px-4 md:px-0">
          <h2 className="text-3xl font-semibold mb-6 text-center">
            Our Leaders
          </h2>
          <p className="text-lg text-center mb-6 max-w-3xl mx-auto">
            Celebrate Recovery is led by trained facilitators who are recovering
            from their own addictions. This creates a non-judgmental and safe
            space for recovery, as each facilitator leads a group related to
            their own recovery journey.
          </p>
          <div className="grid md:grid-cols-2 gap-6 max-w-4xl mx-auto">
            <Card>
              <CardHeader>
                <CardTitle className="flex items-center">
                  <Users className="mr-2 h-6 w-6 text-blue-600" />
                  Sister Myrtle Moody
                </CardTitle>
              </CardHeader>
              <CardContent>
                <p>Exco Member</p>
                <a
                  href="mailto:myrtle.jhn316@gmail.com"
                  className="text-blue-600 hover:underline flex items-center mt-2"
                >
                  <Mail className="mr-2 h-5 w-5" />
                  myrtle.jhn316@gmail.com
                </a>
              </CardContent>
            </Card>
            <Card>
              <CardHeader>
                <CardTitle className="flex items-center">
                  <Users className="mr-2 h-6 w-6 text-blue-600" />
                  Mr. William & Mrs. Gcinile Mofokeng
                </CardTitle>
              </CardHeader>
              <CardContent>
                <a
                  href="mailto:mokete.mofokeng111@gmail.com"
                  className="text-blue-600 hover:underline flex items-center mt-2"
                >
                  <Mail className="mr-2 h-5 w-5" />
                  mokete.mofokeng111@gmail.com
                </a>
              </CardContent>
            </Card>
          </div>
        </section>

        <section id="contact" className="mb-16 px-4 md:px-0">
          <h2 className="text-3xl font-semibold mb-6 text-center">
            Contact Us
          </h2>
          <Card className="max-w-2xl mx-auto">
            <CardContent className="p-6">
              <div className="flex items-center mb-4">
                <Mail className="mr-2 h-5 w-5 text-blue-600" />
                <a
                  href="mailto:myrtle.jhn316@gmail.com"
                  className="text-blue-600 hover:underline"
                >
                  myrtle.jhn316@gmail.com
                </a>
              </div>
              <div className="flex items-center mb-4">
                <Mail className="mr-2 h-5 w-5 text-blue-600" />
                <a
                  href="mailto:mokete.mofokeng111@gmail.com"
                  className="text-blue-600 hover:underline"
                >
                  mokete.mofokeng111@gmail.com
                </a>
              </div>
            </CardContent>
          </Card>
        </section>
      </main>
    </div>
  );
}
