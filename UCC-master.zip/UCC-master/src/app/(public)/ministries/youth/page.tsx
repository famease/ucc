import React from "react";
import YouthMinistry from "./Youth";
import { Metadata } from "next";

export const metadata: Metadata = {
  title: "One2Nine Generation Youth Ministry",
  description:
    "Join our youth ministry One2Nine Generation for spiritual growth, leadership development, and community engagement.",
  keywords: [
    "youth ministry bellavista",
    "christian youth",
    "youth group bellvista",
    "church youth group bellvista",
    "church for teens",
    "youth programs",
    "teen church programs",
    "One2Nine Generation",
    "UCC missions ministry",
    "feed children weekly",
    "church information",
    "make donations",
    "banking details",
    "church times",
    "ministries"
  ],
  openGraph: {
    title: "One2Nine Generation Youth Ministry",
    description:
      "Join our youth ministry One2Nine Generation for spiritual growth, leadership development, and community engagement.",
    url: "https://urcc.co.za/ministries/youth",
    type: "website",
    locale: "en_ZA",
  },
};

function page() {
  return (
    <div>
      <YouthMinistry />
    </div>
  );
}

export default page;
