import Image from "next/image";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import {
  Calendar,
  Clock,
  MapPin,
  Mail,
  Phone,
  Users,
  FlameIcon as Fire,
  Heart,
  Star,
  Music,
  Compass,
  Book,
  Shuffle,
  Target,
  Instagram,
} from "lucide-react";
import {
  RiCrossFill,
  RiFacebookCircleLine,
  RiFacebookLine,
  RiInstagramLine,
  RiTiktokLine,
} from "@remixicon/react";

export default function YouthMinistry() {
  return (
    <div className="min-h-screen bg-background">
      <header className="bg-primary text-primary-foreground py-20 relative overflow-hidden">
        <Image
          src="/cross.webp?height=400&width=1200"
          alt="Youth worshipping"
          width={1200}
          height={400}
          className="absolute inset-0 object-fill opacity-20"
        />
        <div className="container mx-auto px-4 relative z-10">
          <h1 className="text-5xl md:text-7xl font-extrabold mb-4 leading-tight">
            One2Nine Generation
          </h1>
          <p className="text-xl md:text-2xl font-medium max-w-2xl">
            1 Peter 2:9 (NIV) says:{" "}
            <b>
              &#34;But you are a chosen people, a royal priesthood, a holy
              nation, God&#39;s special possession, that you may declare the
              praises of him who called you out of darkness into his wonderful
              light.&#34;
            </b>
          </p>
        </div>
      </header>

      <main className="container mx-auto px-4 py-16">
        <section className="mb-20">
          <h2 className="text-3xl md:text-4xl font-bold mb-8 text-center text-foreground">
            About Our Youth Ministry
          </h2>
          <div className="flex flex-col md:flex-row items-center gap-12">
            <div className="md:w-1/2">
              <p className="text-lg leading-relaxed text-muted-foreground mb-6">
                One2Nine Generation is a dynamic youth ministry committed to
                nurturing faith, character, and leadership in our
                community&#39;s young people. We&#39;re passionate about
                empowering the next generation to live out their faith boldly
                and create positive change in the world.
              </p>
              <p className="text-lg leading-relaxed text-muted-foreground">
                Through engaging activities, meaningful worship, and supportive
                fellowship, we guide youth in discovering their identity and
                purpose in Christ. Join us as we pursue excellence in our
                spiritual journey!
              </p>
            </div>
            <div className="md:w-1/2">
              <Image
                src="/youth1.webp?height=400&width=600"
                alt="Youth group engaged in worship"
                width={600}
                height={400}
                className="rounded-lg shadow-xl"
              />
            </div>
          </div>
        </section>

        <section className="mb-20">
          <h2 className="text-3xl md:text-4xl font-bold mb-8 text-center text-foreground">
            Our Mission
          </h2>
          <div className="grid grid-cols-2 md:grid-cols-5 gap-6 max-w-5xl mx-auto">
            {[
              {
                icon: Fire,
                title: "Worship",
                description: "Cultivate a passion for God",
              },
              {
                icon: Compass,
                title: "Growth",
                description: "Foster spiritual development",
              },
              {
                icon: Heart,
                title: "Identity",
                description: "Discover purpose in Christ",
              },
              {
                icon: Star,
                title: "Influence",
                description: "Impact communities positively",
              },
              {
                icon: Music,
                title: "Excellence",
                description: "Pursue quality in all we do",
              },
            ].map((item, index) => (
              <Card
                key={index}
                className="bg-card shadow-lg hover:shadow-xl transition-shadow duration-300"
              >
                <CardHeader>
                  <CardTitle className="flex flex-col items-center text-center">
                    <item.icon className="mb-4 h-10 w-10 text-primary" />
                    <span className="text-lg font-semibold text-card-foreground">
                      {item.title}
                    </span>
                  </CardTitle>
                </CardHeader>
                <CardContent>
                  <p className="text-sm text-center text-muted-foreground">
                    {item.description}
                  </p>
                </CardContent>
              </Card>
            ))}
          </div>
        </section>

        <section className="mb-20">
          <h2 className="text-3xl md:text-4xl font-bold mb-8 text-center text-foreground">
            Our Values: ACTIIVE
          </h2>
          <div className="grid grid-cols-2 md:grid-cols-4 gap-6 max-w-6xl mx-auto">
            {[
              {
                letter: "A",
                value: "Available",
                icon: RiCrossFill,
                description: "Ready to serve",
              },
              {
                letter: "C",
                value: "Committed",
                icon: RiCrossFill,
                description: "Dedicated to our calling",
              },
              {
                letter: "T",
                value: "Teachable",
                icon: RiCrossFill,
                description: "Always learning",
              },
              {
                letter: "I",
                value: "Intimate",
                icon: RiCrossFill,
                description: "Close-knit community",
              },
              {
                letter: "I",
                value: "Influential",
                icon: RiCrossFill,
                description: "Positive impact",
              },
              {
                letter: "V",
                value: "Versatile",
                icon: RiCrossFill,
                description: "Adaptable approach",
              },
              {
                letter: "E",
                value: "Effective",
                icon: RiCrossFill,
                description: "Results-oriented",
              },
            ].map((item, index) => (
              <Card
                key={index}
                className="bg-card shadow-lg hover:shadow-xl transition-shadow duration-300"
              >
                <CardHeader className="pb-2">
                  <CardTitle className="flex items-center justify-between">
                    <span className="text-3xl font-bold text-primary">
                      {item.letter}
                    </span>
                    <item.icon className="h-6 w-6 text-secondary" />
                  </CardTitle>
                </CardHeader>
                <CardContent>
                  <p className="text-lg font-semibold text-card-foreground mb-1">
                    {item.value}
                  </p>
                  <p className="text-sm text-muted-foreground">
                    {item.description}
                  </p>
                </CardContent>
              </Card>
            ))}
          </div>
        </section>

        <section className="mb-20">
          <h2 className="text-3xl md:text-4xl font-bold mb-8 text-center text-foreground">
            Our Ministry Activities
          </h2>
          <div className="grid md:grid-cols-2 gap-8 max-w-5xl mx-auto">
            {[
              {
                title: "Weekly Youth Service",
                description:
                  "Every Sunday at 8 AM, join us for inspiring worship, relevant teaching, and vibrant fellowship.",
                icon: Calendar,
              },
              {
                title: "Small Group Bible Studies",
                description:
                  "Last Saturday of the month at 9 AM, dive deeper into God's Word in an intimate, discussion-based setting.",
                icon: Users,
              },
              {
                title: "Monthly Outreach Programs",
                description:
                  "Engage in various community service activities, sharing God's love through practical acts of kindness.",
                icon: Heart,
              },
              {
                title: "Annual Youth Camp",
                description:
                  "Join us each summer for an unforgettable weekend of spiritual growth, adventure, and lasting friendships.",
                icon: Compass,
              },
            ].map((item, index) => (
              <Card
                key={index}
                className="bg-card shadow-lg hover:shadow-xl transition-shadow duration-300"
              >
                <CardHeader>
                  <CardTitle className="flex items-center text-xl text-card-foreground">
                    <item.icon className="mr-3 h-6 w-6 text-primary" />
                    {item.title}
                  </CardTitle>
                </CardHeader>
                <CardContent>
                  <p className="text-muted-foreground">{item.description}</p>
                </CardContent>
              </Card>
            ))}
          </div>
        </section>

        <section className="mb-20">
          <h2 className="text-3xl md:text-4xl font-bold mb-8 text-center text-foreground">
            Connect with Our Youth Leaders
          </h2>
          <Card className="max-w-2xl mx-auto bg-card shadow-lg">
            <CardHeader>
              <CardTitle className="flex items-center justify-center text-2xl text-card-foreground">
                <Users className="mr-3 h-7 w-7 text-primary" />
                Youth Ministry Team
              </CardTitle>
            </CardHeader>
            <CardContent className="p-6 flex flex-col items-center">
              <div className="flex items-center justify-center mb-4">
                <Mail className="mr-3 h-5 w-5 text-primary" />
                <a
                  href="mailto:uccjhbsouth@gmail.com"
                  className="text-lg text-primary hover:underline"
                >
                  uccjhbsouth@gmail.com
                </a>
              </div>
              <div className="flex items-center justify-center">
                <Phone className="mr-3 h-5 w-5 text-primary" />
                <a
                  href="tel:+27 78 070 0179"
                  className="text-lg text-primary hover:underline"
                >
                  078 070 0179
                </a>
              </div>
            </CardContent>
          </Card>
        </section>

        <section className="mb-20">
          <h2 className="text-3xl md:text-4xl font-bold mb-8 text-center text-foreground">
            Join the One2Nine Generation!
          </h2>
          <div className="text-center max-w-3xl mx-auto">
            <p className="text-lg mb-8 text-muted-foreground">
              We invite all youth to become part of our vibrant community.
              Experience the transformative power of God&#39;s love and discover
              your unique purpose in Christ. No pre-registration needed – simply
              join us and be prepared for an incredible journey of faith!
            </p>
            {/* <Button
              size="lg"
              className="text-lg px-8 py-6 bg-primary text-primary-foreground hover:bg-primary/90 transition-all duration-300 shadow-lg hover:shadow-xl mb-8"
            >
              <a href="#contact" className="flex items-center font-semibold">
                Get Connected Today
              </a>
            </Button> */}

            <div className="flex justify-center space-x-6 mt-8">
              <Button
                size="icon"
                variant="outline"
                className="w-12 h-12 rounded-full social-icon-button bg-primary"
                asChild
              >
                <a
                  href="https://www.facebook.com/one2nine"
                  target="_blank"
                  rel="noopener noreferrer"
                  aria-label="Facebook"
                >
                  <RiFacebookLine className="h-6 w-6 text-primary-foreground" />
                </a>
              </Button>
              <Button
                size="icon"
                variant="outline"
                className="w-12 h-12 rounded-full social-icon-button bg-primary"
                asChild
              >
                <a
                  href="https://www.instagram.com/one2ninegen"
                  target="_blank"
                  rel="noopener noreferrer"
                  aria-label="Instagram"
                >
                  <RiInstagramLine className="h-6 w-6 text-primary-foreground" />
                </a>
              </Button>
              <Button
                size="icon"
                variant="outline"
                className="w-12 h-12 rounded-full social-icon-button bg-primary"
                asChild
              >
                <a
                  href="https://www.tiktok.com/@one2nine"
                  target="_blank"
                  rel="noopener noreferrer"
                  aria-label="TikTok"
                >
                  <RiTiktokLine className="h-6 w-6 text-primary-foreground" />
                </a>
              </Button>
            </div>
          </div>
        </section>
      </main>
    </div>
  );
}
