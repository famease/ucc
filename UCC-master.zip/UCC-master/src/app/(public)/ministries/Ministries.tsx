'use client'
import Link from "next/link";
import { motion } from "framer-motion";
import Image from "next/image";
import { ministries } from "@/types/ministry";

interface CardProps {
  name: string;
  image: string;
  link: string;
}

const Card = ({ name, image, link }: CardProps) => (
  <Link href={link} className="group relative overflow-hidden rounded-lg">
    <motion.div
      whileHover={{ scale: 1.05 }}
      className="relative h-full w-full overflow-hidden"
    >
      <Image
        src={image}
        alt={name}
        className="h-full w-full object-cover transition-transform duration-300 group-hover:scale-110"
        width={500}
        height={300}
      />
      <div className="absolute inset-0 bg-black bg-opacity-40 transition-opacity duration-300 group-hover:opacity-75" />
      <div className="absolute inset-0 flex items-center justify-center">
        <h2 className="text-2xl font-bold text-white text-center">{name}</h2>
      </div>
    </motion.div>
  </Link>
);

export default function Component() {
  return (
    <div className="container mx-auto px-4 py-8">
      <h1 className="text-4xl font-bold mb-8 text-center">
        Browse Our Ministries
      </h1>
      <div className="grid grid-cols-2 md:grid-cols-3 gap-4">
        {ministries.map((card, index) => (
          <Card key={index} {...card} />
        ))}
      </div>
    </div>
  );
}
