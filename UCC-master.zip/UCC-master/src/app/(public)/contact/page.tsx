import type { Metadata } from "next";
import { ClockIcon } from "lucide-react";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { RiMailFill, RiPhoneFill, RiMapPin2Fill } from "@remixicon/react";
import ContactPage from "@/components/contact-page";

// Metadata configuration
export const metadata: Metadata = {
  title: "Contact Upperroom Christian Center | Location & Service Times",
  description:
    "Visit Upperroom Christian Center in Haddon, JHB South. Sunday services at 10:30 AM. Located at 2-4 Reeders St. Call us: 011 683 0075.",
  keywords: [
    "church Haddon",
    "Upperroom Christian Center location",
    "church service times JHB South",
    "Christian church Johannesburg",
    "UCC missions ministry",
    "feed children weekly",
    "church information",
    "make donations",
    "banking details",
    "church times",
    "ministries"
  ],
  openGraph: {
    title: "Contact Upperroom Christian Center | Location & Service Times",
    description:
      "Visit us in Haddon, JHB South. Sunday services 10:30 AM, Tuesday Fellowship 7:00 PM.",
    url: "https://urcc.co.za/contact",
    type: "website",
    locale: "en_ZA",
  },
};

// JSON-LD Schema
const jsonLd = {
  "@context": "https://schema.org",
  "@type": "Church",
  name: "Upperroom Christian Center",
  description: "A vibrant Christian community in Haddon, Johannesburg South.",
  url: "https://urcc.co.za/contact",
  telephone: "011 683 0075",
  email: "uccjhbsouth@gmail.com",
  address: {
    "@type": "PostalAddress",
    streetAddress: "2-4 Reeders St",
    addressLocality: "Haddon",
    addressRegion: "Johannesburg",
    postalCode: "2190",
    addressCountry: "ZA",
  },
  geo: {
    "@type": "GeoCoordinates",
    latitude: "-26.2563217",
    longitude: "28.0314078",
  },
  openingHours: ["Su 10:30-12:30", "Tu 19:00-20:00"], //to update
};

export default function page() {
  return (
    <div className="min-h-screen bg-gray-50 py-8 sm:py-12">
      <script
        type="application/ld+json"
        dangerouslySetInnerHTML={{ __html: JSON.stringify(jsonLd) }}
      />
      <div className="container mx-auto px-4">
        <h1 className="text-3xl sm:text-4xl font-bold text-center mb-8 sm:mb-12">
          Contact Us
        </h1>

        <div className="grid gap-8 lg:grid-cols-2">
          {/* Map and Contact Information */}
          <div className="space-y-8">
            <Card>
              <CardHeader>
                <CardTitle>Our Location</CardTitle>
              </CardHeader>
              <CardContent>
                <div className="aspect-video mb-4">
                  <iframe
                    src="https://www.google.com/maps/embed?pb=!1m14!1m8!1m3!1d14312.65828598568!2d28.0314078!3d-26.2563217!3m2!1i1024!2i768!4f13.1!3m3!1m2!1s0x1e950f3aba26b309%3A0xcc0c81e944a5927e!2sUpper%20Room%20Christian%20Centre!5e0!3m2!1sen!2sza!4v1725973967085!5m2!1sen!2sza"
                    width="100%"
                    height="100%"
                    style={{ border: 0 }}
                    allowFullScreen
                    loading="lazy"
                    referrerPolicy="no-referrer-when-downgrade"
                  ></iframe>
                </div>
                <div className="space-y-4">
                  <div className="flex items-center">
                    <RiMapPin2Fill className="h-5 w-5 mr-2 text-primary flex-shrink-0" />
                    <span className="text-sm sm:text-base">
                      2-4 Reeders St, Haddon, JHB South 2190
                    </span>
                  </div>
                  <div className="flex items-center">
                    <RiPhoneFill className="h-5 w-5 mr-2 text-primary flex-shrink-0" />
                    <span className="text-sm sm:text-base"></span>
                    <a
                      href="tel:011 683 0075"
                      className="text-sm sm:text-base underline"
                    >
                      011 683 0075
                    </a>
                  </div>
                  <div className="flex items-center">
                    <RiMailFill className="h-5 w-5 mr-2 text-primary flex-shrink-0" />
                    <a
                      href="mailto:uccjhbsouth@gmail.com"
                      className="text-sm sm:text-base underline"
                    >
                      uccjhbsouth@gmail.com
                    </a>
                  </div>
                </div>
              </CardContent>
            </Card>

            <Card>
              <CardHeader>
                <CardTitle>Service Times</CardTitle>
              </CardHeader>
              <CardContent>
                <div className="space-y-4">
                  <div className="flex items-center">
                    <ClockIcon className="h-5 w-5 mr-2 text-primary flex-shrink-0" />
                    <span className="text-sm sm:text-base">
                      Sunday: 10:30 AM to 12:30 PM
                    </span>
                  </div>
                  <div className="flex items-center">
                    <ClockIcon className="h-5 w-5 mr-2 text-primary flex-shrink-0" />
                    <span className="text-sm sm:text-base">
                      Tuesday Fellowship: 7:00 PM to 8:00 PM
                    </span>
                  </div>
                </div>
              </CardContent>
            </Card>
          </div>

          {/* Contact Form */}
          <ContactPage />
        </div>
      </div>
    </div>
  );
}
