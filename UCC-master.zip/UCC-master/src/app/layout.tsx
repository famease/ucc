import type { Metadata } from "next";
import { Merriweather } from "next/font/google";
import "./globals.css";
import { Navbar } from "@/components/Navbar";
import { Footer } from "@/components/footer";
import { Toaster } from "@/components/ui/toaster";
import { MinistriesCarousel } from "@/components/ministries-carousel";
import { BackToTopButton } from "@/components/back-to-top-button";

const merriweather = Merriweather({ weight: "300", subsets: ["latin"] });

export const metadata: Metadata = {
  metadataBase: new URL("https://urcc.co.za/"),
  title: {
    default:
      "The Upperroom Christian Center | Christian Church in Haddon/Bellavista, Johannesburg South",
    template: "%s | UCC Haddon - Bellavista",
  },

  description:
    "Upperroom Christian Center (UCC) is a vibrant Christian church located in the Haddon/Bellavista area of Johannesburg South. We offer dynamic worship services, youth programs, and community outreach in the Southern suburbs of Johannesburg.",
  keywords: [
    "Christian church Johannesburg South",
    "Haddon church",
    "Bellavista church",
    "Christian church Johannesburg",
    "UCC church South Africa",
    "UCC missions ministry",
    "feed children weekly",
    "church information",
    "make donations",
    "banking details",
    "church times",
    "ministries",
  ],
  verification: {
    google: "2e786e07f50216bb",
  },
  openGraph: {
    type: "website",
    locale: "en_ZA",
    url: "https://urcc.co.za/",
    siteName: "Upperroom Christian Center",
    images: [
      {
        url: "https://urcc.co.za/ucc-logo.jpg",
        width: 1200,
        height: 630,
        alt: "UCC",
      },
    ],
  },
};

export default function RootLayout({
  children,
}: Readonly<{
  children: React.ReactNode;
}>) {
  return (
    <html lang="en">
      <body className={merriweather.className}>
        <Navbar />
        {children}
        <MinistriesCarousel />
        <BackToTopButton />
        <Footer />
        <Toaster />
      </body>
    </html>
    // </ClerkProvider>
  );
}
