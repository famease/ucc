import { AboutUsSection } from "@/components/about-us-section";
import { Hero } from "@/components/Hero";
import { MissionSection } from "@/components/mission-section";
import { ServiceTimesSection } from "@/components/service-times-section";
import { Metadata } from "next";
import React from "react";

export const metadata: Metadata = {
  title: "Upperroom Christian Center | Our Church",
  description: "Upperroom Christian Center | Haddon, Johannesburg.",
  verification: {
    google: "2e786e07f50216bb",
  },
  robots: {
    index: true,
    follow: true,
  },
  keywords: [
    "Upperroom Christian Center",
    "church history Haddon",
    "church mission JHB South",
    "UCC JHB south",
    "Upperroom Christian Center Bellavista",
    "UCC Johannesburg south",
    "UCC Bellavista",
    "UCC Haddon",
    "UCC missions ministry",
    "feed children weekly",
    "church information",
    "make donations",
    "banking details",
    "church times",
    "ministries",
  ],
  openGraph: {
    type: "website",
    locale: "en_ZA",
    url: "https://urcc.co.za/",
    siteName: "Upperroom Christian Center",
    images: [
      {
        url: "https://urcc.co.za/ucc-logo.jpg",
        width: 1200,
        height: 630,
        alt: "UCC",
      },
    ],
  },
  viewport: "width=device-width, initial-scale=1.0",
};

function Home() {
  return (
    <div>
      <Hero />
      <MissionSection />
      <AboutUsSection />
      <ServiceTimesSection />
      {/* <UpcomingEvents />
      <ChurchBlogSection /> */}
    </div>
  );
}

export default Home;
