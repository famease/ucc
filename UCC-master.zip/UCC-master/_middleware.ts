import { clerkMiddleware, createRouteMatcher } from "@clerk/nextjs/server";
import { NextResponse } from "next/server";
import type { NextRequest } from "next/server";

// Define a function to match the admin route
const isAdminRoute = createRouteMatcher(["/admin(.*)"]);

// Export the middleware function
export default clerkMiddleware((auth, req: NextRequest) => {
  // Extract user information from auth
  const { userId } = auth();

  // Check if the user is logged in
  if (!userId) {
    // If the user is not logged in, redirect to login
    return NextResponse.redirect(new URL('/login', req.url));
  }

  // Check if the current request is for the admin route
  if (isAdminRoute(req)) {
    // For the admin route, perform additional checks
    // You can add more specific conditions here if needed
    // For now, we'll just check if the user has an admin flag (you'll need to implement this)
    const isAdmin = checkIfUserIsAdmin(userId);
    if (!isAdmin) {
      // If the user is not an admin, redirect to a forbidden page or home
      return NextResponse.redirect(new URL('/forbidden', req.url));
    }
  }

  // If the user is logged in and passes all checks, allow access
  return NextResponse.next();
});

// This function should be implemented to check if a user is an admin
// This is just a placeholder - you'll need to replace it with actual logic
function checkIfUserIsAdmin(userId: string): boolean {
  // Implement your admin check logic here
  // For example, you might query a database or check a user's metadata
  return false; // Replace with actual implementation
}

// Configuration for the middleware to determine which routes to run on
export const config = {
  matcher: [
    "/((?!_next|\\.jpg|\\.jpeg|\\.gif|\\.png|\\.webp|\\.svg|\\.ico|\\.ttf|\\.woff|\\.woff2|\\.css|\\.js).*)",
    "/(api|trpc)(.*)",
  ],
};