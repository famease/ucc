module.exports = {
  siteUrl: "https://urcc.co.za/",
  generateRobotsTxt: true,
  exclude: ["/admin/*"],
  robotsTxtOptions: {
    policies: [
      {
        userAgent: "*",
        allow: "/",
        disallow: ["/admin"],
      },
    ],
  },
  priority: 0.7,
  changefreq: "weekly",
};
